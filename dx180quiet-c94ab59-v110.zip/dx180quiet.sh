#!/system/bin/sh
#
# dx180quiet.sh — consolidated CPU/cpuset controller for the DX180 audio appliance.
#
# One file, several entry points, dispatched by the first argument. The components have three
# distinct lifetimes that a single linear script cannot express, so they are separated into
# subcommands invoked by init (service.sh) and by inotifyd:
#
#   boot       run-once boot preparation: stop services, disable/stop apps, set the CPU/GPU baseline,
#              establish the cpuset partition, drain the root cpuset, sort IRQ affinity, then launch
#              the two daemons.
#   forkwatch  run-forever: block on a sched_process_fork trace_pipe and re-drain any userspace that
#              lands back in the root cpuset (pushes newly spawned processes off the little cluster).
#   maintslow  run-forever alternative to forkwatch: a coarse interval scan of the root cpuset only.
#   pcm        run-per-event: invoked by inotifyd on PCM open/close. Pulls the render threads onto the
#              little cluster and sets the little-cluster frequency tier. inotifyd supplies its own
#              argument signature (<events> <path> <filename>); that signature is routed here via the
#              catch-all case.
#   irqsort    run-on-demand: the IRQ affinity sort and the threaded-handler pass, for re-applying them
#              after a list change
#   wqconfine  run-on-demand: the unbound workqueue cpumask write on its own
#              without a reboot.
#   irqcheck   read-only: how many sorted interrupts have since left their target, and which. The same
#              pass maintslow runs on its interval.
#   irqstat    read-only report: per-interrupt affinity, effective affinity and per-core counts. The
#              verification instrument for the sort.
#   irqrate    read-only: interrupt RATE over an interval (default 30s), busiest first. The instrument
#              for judging whether a change actually reduced traffic, which a cumulative count cannot.
#   wifigated  run-forever: monitors screen state, PCM state and network traffic. When the screen is
#              off and the PCM is open and traffic has been idle for WIFI_QUIET_SECS, disables wifi.
#              Re-enables immediately on screen-on or PCM-close. Only launched when WIFI_GATE=1.
#   revert     live rollback: stop daemons, restore stock cpuset masks, remove custom sets and the
#              trace instance. IRQ affinity is not restored; see the note above pin_irqs.
#
# Direction of the two daemons is opposite and non-colliding: forkwatch evicts everything from the
# littles by moving root-resident tasks to the big cluster; the pcm handler is the only path that
# places tasks ONTO the littles, and only the identified render threads. Because forkwatch acts solely
# on tasks still resident in the root cpuset, a render thread already moved into the audio set is not
# touched.
#
# All cpuset, cpufreq and IRQ-affinity writes are runtime sysfs and revert on reboot. Ephemeral state lives under
# /dev/dx180 (/dev is tmpfs, wiped on any reboot).
#
# Topology (verified on-device): cpu0-3 little, cpu4-7 big.

# ---------------------------------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------------------------------

SELF=$(readlink -f "$0" 2>/dev/null); [ -n "$SELF" ] || SELF=$0
SHELL_BIN=/system/bin/sh                      # explicit interpreter for the daemons (see launch_daemons)

CPUSET=/dev/cpuset
LITTLE="0-3"
BIG="4-7"
MUSICPKG="app.symfonik.music.player"

AUDIO_SET="$CPUSET/audio"                     # render path holder on the littles (populated by pcm)
BIGSINK="$CPUSET/bigsink"                     # destination for drained root tasks and caught forks

STATE_DIR=/dev/dx180                          # ephemeral (tmpfs); holds snapshot, lock, pidfiles
BAK="$STATE_DIR/part.bak"                     # stock cpus snapshot for live revert
AUDIOHAL_TARGET="$STATE_DIR/audiohal.target"  # memoised audio HAL pid; not a daemon pidfile
LOCKDIR="$STATE_DIR/pcm.lock"                 # serializes overlapping pcm handlers (mkdir-based)

LOG="${LOG:-/data/local/tmp/dx180quiet.log}"
LOG_MAX=262144                                # bytes; truncated past this at boot

CARD="${CARD:-0}"
PCM_NODE="/dev/snd/pcmC0D0p"
HWP="/proc/asound/card${CARD}/pcm0p/sub0/hw_params"
POLICY0=/sys/devices/system/cpu/cpufreq/policy0   # little-cluster cpufreq policy

# Little-cluster frequency tiers (kHz). Values require tuning against scaling_available_frequencies:
#     cat $POLICY0/scaling_available_frequencies | tr ' ' '\n' | sort -n
FREQ_IDLE=300000                          # floor when no stream holds the PCM
FREQ_IDLE_MAX=300000                      # modest idle ceiling for an unstarved restart
FREQ_STD=614400                           # rate <= 48000
FREQ_HIRES=614000                         # 88200 .. 192000
FREQ_ULTRA=864000                         # 88200 .. 192000
GPU_MAX=320                               # gpu_max_clock at baseline

# devfreq governor applied to the DDR bandwidth devices at baseline. Empty leaves them alone.
#
# The stock governor is bw_hwmon, which is the client behind irq/66-1b8e200.qcom,cpu-cpu-ddr-bwmon
# (44,898 cpu0 counts in the 2026-09-26 capture). It samples bandwidth and re-votes, and each vote is
# an RPM message — which is the same path as irq/20-rpm-glink, the largest non-storage interrupt source
# on the device at 131,778 counts. A static governor stops the sampling interrupt and removes that
# governor's share of the RPM traffic in one write.
#
# Left empty by default because the trade is real rather than free: `performance` holds the DDR vote at
# maximum, which costs battery on a device that is otherwise idle, and `powersave` holds it at minimum,
# which risks starving bandwidth under load. `userspace` with a fixed setpoint is the middle road. The
# device names are not stable enough to hard-code — on this build the relevant one is
# soc:qcom,cpu-cpu-ddr-bw — so the target is matched by substring against DDR_BW_MATCH.
DDR_BW_GOV="${DDR_BW_GOV-}"
DDR_BW_MATCH="${DDR_BW_MATCH-cpu-cpu-ddr}"
#FREQ_HIRES=864000                        # 88200 .. 192000
#FREQ_ULTRA=1401600                        # rate > 192000 or native DSD
BIG_MAX=902000							# This is here, but doesn't currently d anything; on the todo list

# Behavior flags (environment-overridable).
SINK_INIT="${SINK_INIT:-1}"                       # 1 also moves init (pid 1) to the bigs sink
DISABLE_SWEEP="${DISABLE_SWEEP:-1}"               # 1 runs the service-stop / app-disable sweep at boot
INCLUDE_AUDIOSERVER="${INCLUDE_AUDIOSERVER:-1}"   # 1 also pulls audioserver mixer threads to littles
INCLUDE_AUDIOHAL="${INCLUDE_AUDIOHAL:-1}"         # 1 also pulls the audio HAL's writer thread to the littles
AUDIOHAL_COMM="${AUDIOHAL_COMM:-audio.service}"   # process comm of the audio HAL (see audiohal_pid)
MAINT="${MAINT:-slow}"                            # fork | slow (maintenance daemon selection)
INTERVAL="${INTERVAL:-25}"                        # seconds between passes in MAINT=slow
QUIET_LOGD="${QUIET_LOGD:-1}"                     # 1 sets persist.log.tag E at baseline (reduces logspam)
PINWATCH="${PINWATCH:-1}"                         # 1 runs the render-thread re-pin daemon (see do_pinwatch)
PIN_INTERVAL="${PIN_INTERVAL:-9}"                 # seconds between re-pin passes while the PCM is held open
IRQ_SORT="${IRQ_SORT:-1}"                         # 1 runs the boot-time IRQ affinity sort (see pin_irqs)
IRQ_DRIFT_CHECK="${IRQ_DRIFT_CHECK:-1}"           # 1 has maintslow report IRQs that have left their target
IRQ_DRIFT_REPIN="${IRQ_DRIFT_REPIN:-1}"           # 1 has maintslow re-apply affinity to drifted IRQs (requires IRQ_DRIFT_CHECK=1)
STOPAPPS_ON_PCM="${STOPAPPS_ON_PCM:-1}"           # 1 lets a PCM open trigger the STOPAPPS sweep (rate-limited)
STOPAPPS_MIN_GAP="${STOPAPPS_MIN_GAP:-900}"       # minimum seconds between PCM-triggered STOPAPPS sweeps
IRQ_THREADS="${IRQ_THREADS:-1}"                   # 1 also affines the irq/<n>-* threaded handlers (see pin_irq_threads)
WQ_CPUS="${WQ_CPUS-$BIG}"                         # cpus unbound workqueue work is confined to ("" leaves it alone)
KTHREAD_SORT="${KTHREAD_SORT:-1}"                 # 1 runs the boot-time kernel-thread affinity sort (see pin_kthreads)
KTHREAD_CPUS="${KTHREAD_CPUS-$BIG}"               # destination for unclassified kernel threads ("" disables the move)

# Destination for the interrupts this module classes as noise, and the one cpu set in this file that is
# NOT derived from the cluster topology.
#
# The first version of the sort pushed them to $BIG, which does not hold. The 2026-09-26 boot verified 97
# affinity writes at 10:43:42; fifteen minutes later 93 of them read back as cpu0. An interrupt masked to
# 4-7 loses the mask itself the first time the kernel finds no online cpu inside it — on suspend, on
# hotplug, or on core_ctl isolation, all of which reassign it and rewrite the mask. An interrupt masked to
# cpu0 cannot suffer that: cpu0 is the boot cpu and does not go offline on this platform, so the placement
# is stable with no re-application, no daemon, and no fight. The kernel was already doing this — 93 of the
# 97 ended up here on its own — so targeting cpu0 changes nothing about the steady state reached in
# practice, and only makes it deterministic and immediate rather than arrived at over minutes.
#
# The consequence is that cpu0 becomes a deliberate interrupt sink carrying six-figure counts, and
# cpu1-3 are left clean. AUDIO_CPUS below is the other half of that arrangement.
IRQ_NOISE_CPUS="${IRQ_NOISE_CPUS-0}"

# Cpus the audio cpuset and the audio-path interrupts are confined to. Defaults to cpu1-3, the little
# cluster minus the interrupt sink.
#
# This is the other half of the IRQ_NOISE_CPUS arrangement: cpu0 absorbs the interrupt load, cpu1-3 carry
# nothing but the render path. It narrows the render threads from four cores to three, which is an
# audible change; subjective evaluation on 2026-09-29 reported the render path holding under UI load that
# previously disturbed it. Boot with AUDIO_CPUS=0-3 to restore the previous behaviour for comparison.
#
# Note this does not change the cpufreq window: policy0 covers cpu0-3 as one cluster, so cpu0 runs at
# whatever tier set_little_freq selects whether or not it holds any render threads.
#
# No downstream derivation exists: nothing subtracts $IRQ_NOISE_CPUS from $LITTLE to arrive at an audio
# set. This assignment is the only place the audio cpuset's membership is decided, which is why the
# default of $LITTLE placed render threads on cpu0 alongside the interrupt sink. The default is 1-3,
# matching IRQ_NOISE_CPUS=0. Retaining the ${AUDIO_CPUS-...} form keeps `AUDIO_CPUS=0-3 sh dx180quiet.sh
# boot` available for comparison against the previous behaviour without editing this file.
#
# Previously set to 2-3 to dodge glink-native (IRQ 20) drifting onto cpu1. Reverted to 1-3 because
# AUDIO_CPUS=2-3 causes system_server cpuset migrations to land the render path on the big cluster
# (observed as ExoPlayer/AudioTrack/AudioEngine at allow=4-7), while 1-3 does not exhibit this.
# The glink drift is now addressed by IRQ_DRIFT_REPIN, which re-applies the affinity from the
# maintslow loop rather than surrendering cpu1.
AUDIO_CPUS="${AUDIO_CPUS-1-3}"

# IRQ affinity sort lists, matched as substrings against the interrupt's ACTION NAME rather than its
# number: IRQ numbers are not stable across kernel versions or device-tree revisions, whereas the
# action name registered by the driver is. The name is read from /proc/irq/<n>/<action>/ — see
# irq_name().
#
# IRQ_AUDIO_FRAGS — interrupts held on (or moved onto) the little cluster, alongside the render
# threads the pcm handler places there. swr_mas is the SoundWire master controller carrying PCM to the
# codec; it was found on the big cluster in the 2026-09-23 and 2026-09-26 captures, the inverse of the
# stated intent, since every other stage of the render path is confined to the littles. The device
# registers two of them (irq/225, irq/226 — RX and TX macro), and both accept an affinity write.
#
# swr_wak (irq/235, the SoundWire wake interrupt) was in this list and has been REMOVED: it does not
# accept an affinity write on this device. Confirmed on the 2026-09-26 10:43:42 boot, where it appears
# in pin_irqs' rejected list, and in irqstat, where it reads aff=0-7 with no effective_affinity at all.
# It shares that property with the whole wcd937x block (irq/227-234) and with every other PMIC/SPMI and
# TLMM-GPIO line — a secondary irqchip with no irq_set_affinity implementation, where the write returns
# an error and the mask stays at the online set. Listing it achieved nothing except one guaranteed
# entry in the rejected line every boot. The audio half of the sort is therefore swr_mas only.
#
# IRQ_ASIS_FRAGS — interrupts left exactly as found, neither moved nor reported as drift. Originally for
# interrupts whose function was not yet identified; now also for interrupts the kernel manages itself,
# where a userspace placement is not merely useless but wrong.
#
# arch_mem_timer and mpm are there for the second reason. The 2026-09-26 drift log names the same three
# interrupts on every pass — `2-mpm`, `7-arch_mem_timer` and `20-glink-native` — oscillating between cpu2,
# cpu3 and cpu4 and back to the target, while the other ninety-odd hold cpu0 without moving. The first two
# are kernel-managed by design: arch_mem_timer is the memory-mapped timer, retargeted to whichever cpu
# owns the next expiry, and mpm is the wakeup controller, re-affined across suspend to the cpu that
# handled the resume. Pinning either fights the scheduler and the suspend path for no benefit, and
# reporting them as drift every minute buries the one interrupt that is genuinely failing to hold.
#
# `20-glink-native` is deliberately NOT here. It is the RPM edge, the largest non-storage source on the
# device, and it drifting onto an audio core is a real problem rather than a reporting artefact — so it
# stays on the list that keeps trying, and it is now the only thing the drift line reports. Holding its
# placement is addressed by IRQ_DRIFT_REPIN: the maintslow loop re-writes the affinity each pass,
# matching the pattern pinwatch uses for the render threads. Reducing its traffic via DDR_BW_GOV is
# complementary but orthogonal.
#
# The substring `mpm` matches the action name `mpm` on irq/2 and nothing else on this device. It does not
# match the chip name `mpm-gic`, which appears in /proc/interrupts but is never what irq_name returns.
#
# `capture` was its only entry and is resolved. The five handlers irq/188-192 register as action
# "capture bus" on chip mpm-gic, and their /proc/interrupts counts are zero on all eight cores across a
# full boot and playback session (2026-09-26). They are not the camera: the camera subsystem registers
# its own lines under their own names (csiphy ×3, csid ×4, ispif, vfe ×2, dual-vfe-irq, cci — irq/78-90),
# all likewise at zero on a device with no camera in use. Whatever "capture bus" is attached to, it has
# never fired, so its placement is inert and it sorts to the bigs with the rest of the noise.
#
# Deliberately NOT in either list, recorded so the reasoning is not re-derived:
#
#   4744000 / 4784000  Both are sdhci controllers, not the DAC or an FPGA control bus as the issue first
#                      supposed. The assignment is the REVERSE of the first reading: the kernel command
#                      line carries `androidboot.bootdevice=4744000.sdhci` with
#                      `androidboot.fstab_suffix=emmc`, so 4744000 is the internal eMMC (mmc0), and
#                      irq/221 registers as `4784000.sdhci cd` — a card-detect line, which only exists on
#                      a removable slot — so 4784000 is the SD card (mmc1). Two independent signals agree.
#                      This matters for reading counts rather than for placement: mmc1, at 152,831 cpu0
#                      counts in the 2026-09-26 capture against mmc0's 57,017, is the SD card the music is
#                      read from, and is the single largest interrupt source on the device. It is also
#                      irreducible while playing. All five storage lines sort to the noise target.
#   1b8e200            `bimc-bwmon 1b8e200.qcom,cpu-cpu-ddr-bwmon` per the boot log — the DDR bandwidth
#                      monitor backing the bandwidth governor. System noise; sorts to the bigs.
#   smp2p              irq/41, 42, 43. Inter-processor signalling to the modem, ADSP and WCNSS. These
#                      fire on subsystem state changes (SSR), not per audio buffer, so big-cluster
#                      placement adds no per-buffer latency to the render path.
#   rotary-            irq/213, 214, the volume wheel. Listed in the issue's acceptance check, and moot:
#                      like swr_wak it is a TLMM-GPIO line that rejects the affinity write, so it stays
#                      on the online set whatever this file says. Unchanged by the sort, in either
#                      direction.
#
# 44 of the 153 numbered interrupts on this device reject an affinity write outright; the 2026-09-26
# boot log's rejected line enumerates them. They fall into four groups — per-cpu (arch_timer, arm-pmu),
# subsystem doorbells (modem, adsp, cdsp, error_ready_interrupt, smp2p_sleepstate), PMIC/SPMI (pon_*,
# pm-adc5, thr-int-en, qcom,temp-alarm, usb_vbus, volume_up, bq25890_irq, the wcd937x block) and TLMM
# GPIO (TE_GPIO, rotary-encoder, shtsc, fusb302, 4784000.sdhci cd, play, wlanfw-*). None carries an
# effective_affinity_list, which is the tell: they hang off a secondary irqchip that implements no
# irq_set_affinity. No list membership can move them, so the issue's acceptance criterion — no irq/
# thread with a last-run CPU in 0-3 — is not reachable for this set by any userspace means.
#
# Both are expanded with ${VAR-default} rather than the ${VAR:-default} used elsewhere in this file.
# An empty list is a meaningful value for these two — it means "sort everything" and is the expected
# form of the edit once `capture` is identified — and the colon form would silently substitute the
# default for it, leaving an override of '' with no effect.
IRQ_AUDIO_FRAGS="${IRQ_AUDIO_FRAGS-swr_mas}"
IRQ_ASIS_FRAGS="${IRQ_ASIS_FRAGS-arch_mem_timer mpm}"

# Kernel-thread sort lists, matched as substrings against the thread's comm. Same shape and the same
# ${VAR-default} rationale as the two IRQ lists above; see pin_kthreads for the selection rule that
# decides which threads are considered at all.
#
# KTHREAD_AUDIO_FRAGS — kernel threads on the render path, moved onto $AUDIO_CPUS with the render
# threads rather than to the sink. Identified from the 2026-09-30 capture: apr_driver is the Qualcomm
# audio packet router, cs43198_codecs the DAC codec driver's worker, ngd_ the SLIMbus NGD receive and
# notify threads, uaudio_svc the USB-audio service thread, and adsp (which also matches glink_adsp) the
# audio DSP subsystem and its G-Link endpoint.
#
# Note the LPASS_* threads are NOT on this list despite the name. LPASS_CMD, LPASS_CNTL, LPASS_DATA and
# the two LPASS_DCI* threads are diagchar channels for the LPASS subsystem, created by the Qualcomm
# diagnostic driver in the same pattern as MODEM_*, SENSORS_*, NPU_*, CDSP_* and WCNSS_*. They carry
# diagnostic traffic about the audio DSP, not audio, and belong with the rest of the diag block.
KTHREAD_AUDIO_FRAGS="${KTHREAD_AUDIO_FRAGS-apr_driver cs43198 ngd_ uaudio_svc adsp}"

# KTHREAD_ASIS_FRAGS — kernel threads left exactly as found. Membership is by demonstrated hazard, not
# by caution in general:
#   kthreadd      pid 2, the creator of every other kernel thread.
#   msm_watchdog  pets the hardware watchdog. A mask restricted to a cluster core_ctl can isolate turns
#                 a scheduling delay into a watchdog reset.
#   core_ctl/     the isolation governor's own threads. Confining the governor to the cluster whose
#                 isolation it decides is a dependency loop with no upside.
#   watchdog/, khungtaskd
#                 the soft-lockup and hung-task detectors, for the same reason as msm_watchdog.
KTHREAD_ASIS_FRAGS="${KTHREAD_ASIS_FRAGS-kthreadd msm_watchdog core_ctl/ watchdog/ khungtaskd}"

# Wifi power-gating. Disables the wifi radio when the screen is off, the hardware PCM is held open
# (local DAC playback, not network streaming), and network traffic has been idle for WIFI_QUIET_SECS.
# Re-enables immediately on screen-on or PCM-close.
#
# The gate is on the hardware PCM rather than a media session because the player also streams to
# UPnP/DLNA endpoints. A media session is active in both cases, but only local DAC playback holds the
# PCM open. PCM open + network idle = cached local playback, wifi is overhead. Media session active +
# PCM closed = streaming to a network renderer, wifi is essential.
#
# The WLAN_CE_* copy-engine interrupts collectively account for ~13,500 counts per 30-second interval
# on cpu0 (from the evidence.md irqrate capture). Disabling the radio eliminates all of them, plus the
# WCNSS subsystem threads, wificond, the WifiManager threads in system_server, and the wifi HAL.
#
# Control is via `svc wifi disable` / `svc wifi enable`, which is the same path as the settings toggle
# and tears down the driver, supplicant and WCNSS subsystem in the correct order. The alternative —
# ifconfig down or driver unload — leaves framework state inconsistent.
WIFI_GATE="${WIFI_GATE:-1}"                    # 0 disabled by default (opt-in); 1 enables the daemon
WIFI_QUIET_SECS="${WIFI_QUIET_SECS:-20}"       # seconds of low traffic before wifi is disabled
WIFI_IDLE_BYTES="${WIFI_IDLE_BYTES:-1000000}"  # byte delta per sample below which traffic is "idle"
WIFI_POLL="${WIFI_POLL:-5}"                    # seconds between traffic samples within the quiet window
WIFI_IFACE="${WIFI_IFACE:-wlan0}"              # interface to monitor
WIFI_SCREEN_POLL="${WIFI_SCREEN_POLL:-3}"      # seconds between screen-state checks while gated

# init services stopped at boot when present (checked via init.svc.<name>).
STOPSERVS='
ims_rtp_daemon imsqmidaemon imsrcsd imsdatadaemon netmgrd port-bridge adpl dpmd dpmQmiMgr ssgqmigd
ipacm drm mediametrics cnss-daemon ipacm-diag vendor.qti.esepowermanager vendor.qti.hardware.soter
vendor.qti.hardware.tui_comm neuralnetworks_hal_service qti_esepowermanager_service_1_1
wfdhdcphalservice wifidisplayhalservice update_engine rmt_storage tftp_server wfdvndservice traced
mlid tloc_daemon traced_probes statsd incidentd soter-1-0 tui_comm-1-0 vendor.cdsprpcd
vendor.dataadpl vendor.ims_rtp_daemon vendor.imsdatadaemon vendor.imsrcsservice vendor.imsqmidaemon
vendor.ipacm vendor.ipacm-diag vendor.netmgrd vendor.msm_irqbalance vendor.port-bridge vendor.qcc-trd
vendor.rmt_storage vendor.tftp_server vendor.tlocd credstore cdsprpcd qcc-trd
vendor.qti.qesdk.sysservice android.hardware.neuralnetworks vendor.drm-widevine-hal-1-3
vendor.drm-clearkey-hal-1-3 vendor.keymaster-4-1 vendor.qti.vibrator
mediaextractor media.swcodec vendor.qspmsvc vendor.cnss_diag
'
# Deliberate omissions from STOPSERVS, recorded so they are not re-added by a later pass:
#
#   vendor.media.omx   Stopping it produced a sustained ~1/sec ctl.interface_start retry storm against
#                      android.hardware.media.c2@1.0::IComponentStore/software (13,663 occurrences in the
#                      2026-09-13 capture). The 2026-09-23 capture, with the service restored, contains
#                      zero. media.swcodec remains stopped throughout, so the retry loop was driven by the
#                      OMX service's absence rather than by the software Codec2 store.
#
#   vendor.sensors.qti The service exists and is resident (6 threads), but stopping the sensor HAL affects
#                      display rotation and the hall sensor. Held pending a decision; see issue #3.
#
# Entries removed because `stop` acts only on init services and each logged "absent svc" every boot:
#
#   media.extractor               The init service is named mediaextractor (verified against the
#                                 init.svc.* namespace); corrected in place above.
#   drmserver                     No such init service. drm, already listed, is the real one.
#   qspmsvc / cnss_diag           Were in STOPAPPS. The init services are vendor.qspmsvc and
#                                 vendor.cnss_diag; moved here under their real names.
#   com.qualcomm.qti.pasrmanager  A package, not a service. Handled by DISABLEAPPS below.
#   rs.media.module               A package, not a service — and it is com.android.providers.media.module,
#                                 the MediaProvider FUSE daemon backing /storage/emulated/0 (its emulated;0
#                                 and public:179,65 threads are the storage handlers). It must not be
#                                 stopped or disabled; the cpuset partition confines it to the bigs instead.

# Packages set to DISABLED_UNTIL_USED at boot (pm disable-until-used; reversible with pm enable). This
# state still permits an on-demand relaunch, which is the intent here: suppress background work without
# breaking the component if something explicitly asks for it. GMS suppression is the largest background
# and thermal win per the process triage.
#
# The three com.google.android.gms.* sub-entries previously listed here (.supervision, .location.history
# on one line with .persistent and .unstable) are PROCESS names declared by com.google.android.gms, not
# separate packages on this ROM: the 2026-09-28 boot logged "disable failed/absent" for .supervision,
# .persistent and .unstable while com.google.android.gms itself disabled. Disabling the parent package
# covers all of them, so the absent entries are removed.
FREEZEAPPS='
com.google.android.gms.location.history com.google.android.gms com.android.vending
com.google.android.inputmethod.latin
'

# Packages set to DISABLED at boot (pm disable; reversible with pm enable, which do_revert performs).
#
# The distinction from FREEZEAPPS is load-bearing. An app declaring android:persistent="true" is placed
# on ActivityManager's persistent-process list and respawned unconditionally on death, so neither
# `am force-stop` nor `pm disable-until-used` holds it down: DISABLED_UNTIL_USED is still matched by the
# default package queries AMS uses to build that list. dump_procstats.txt from 2026-09-23 shows the
# survivors all carrying a "Persistent: 100%" line, and dx180quiet.log records
# "disabled com.qualcomm.qti.workloadclassifier" at 05:50:00 with the process still resident three hours
# later at a pid predating the sweep. Full DISABLED is excluded from those queries and does stick.
#
# com.android.providers.media.module and com.android.networkstack.process are persistent as well and are
# deliberately NOT listed: the former backs external storage over FUSE, the latter Wi-Fi.
# vendor.qti.qesdk.sysservice is also persistent but shares uid 1000; deferred to issue #6.
#
# Both pasr package names were formerly listed because the on-device name was unresolved. The 2026-09-28
# boot log records "disabled (full) com.qti.pasrservice" with no accompanying failure line, so that is
# the package present on this device and com.qualcomm.qti.pasrmanager is not; the speculative second
# entry is therefore unnecessary and is not carried.
#
# com.qualcomm.qti.workloadclassifier was uninstalled from the device on 2026-09-29 and is retained here
# only so the list remains correct for a device that still carries it. pm disable on an absent package
# fails harmlessly and logs.
DISABLEAPPS='
com.qti.pasrservice com.qualcomm.qti.workloadclassifier
android.ext.services
'

# Packages force-stopped at boot (transient: they may relaunch on demand). Kept off both disable lists
# because disabling documentsui/gsf breaks the file picker and account sync.
STOPAPPS='
com.android.settings io.github.muntashirakon.AppManager com.google.android.gsf
com.cxinventor.file.explorer com.android.documentsui com.termux com.android.inputmethod.latin
'

# ---------------------------------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------------------------------

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }

rotate_log() {
        [ -f "$LOG" ] || return 0
        sz=$(stat -c %s "$LOG" 2>/dev/null || echo 0)
        [ "$sz" -gt "$LOG_MAX" ] && : > "$LOG"
}

# ---------------------------------------------------------------------------------------------------
# cpuset controller-file detection and topology check
# ---------------------------------------------------------------------------------------------------

# Android historically mounts cpuset v1 with noprefix (cpus/mems/tasks); some builds use cpuset.*.
detect_files() {
        if   [ -f "$CPUSET/cpus" ];        then CF=cpus;        MF=mems;        TF=tasks
        elif [ -f "$CPUSET/cpuset.cpus" ]; then CF=cpuset.cpus; MF=cpuset.mems; TF=tasks
        else log "no cpuset controller at $CPUSET"; exit 1; fi
}

# Warns if the little/big ceilings are inverted relative to the assumed 0-3 / 4-7 split.
verify_topology() {
        c0=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)
        c4=$(cat /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq 2>/dev/null)
        [ -n "$c0" ] && [ -n "$c4" ] || { log "topology: cpufreq nodes unreadable; skipping check"; return 0; }
        [ "$c0" -lt "$c4" ] || log "topology: WARN cpu0 ceiling ($c0) !< cpu4 ($c4); masks may be inverted"
}

# ---------------------------------------------------------------------------------------------------
# Self-executability
# ---------------------------------------------------------------------------------------------------

# Restores the execute bit on this file if it is missing.
#
# Magisk's template config.sh applies set_perm_recursive with a 0644 file mode to everything under
# $MODPATH, so a reinstall leaves this script non-executable. The failure that produces is silent and
# highly asymmetric: service.sh invokes the script as `sh dx180quiet.sh boot`, which does not need the
# bit, so boot appears to run perfectly and logs a full, healthy-looking sweep. But inotifyd must exec
# the program it is handed, so every PCM event is dropped with no error recorded anywhere, and the
# backgrounded daemons fail the same way.
#
# Observed on the 2026-09-24 10:10:17 boot: a complete boot block including "maintslow launched" and
# "pinwatch launched", followed by 45 minutes of playback and not one further log line, an empty
# /dev/cpuset/audio, and every render thread left on the big cluster.
ensure_self_exec() {
        [ -x "$SELF" ] && return 0
        if chmod 0755 "$SELF" 2>/dev/null && [ -x "$SELF" ]; then
                log "self: restored execute bit on $SELF (config.sh reset it)"
        else
                log "self: WARN $SELF is not executable and chmod failed; PCM events will be dropped"
        fi
}

# ---------------------------------------------------------------------------------------------------
# Boot sweep: stop services, disable / stop apps
# ---------------------------------------------------------------------------------------------------

stop_services() {
        for svc in $STOPSERVS; do
                st=$(getprop "init.svc.$svc")
                if [ -n "$st" ]; then
                        stop "$svc" 2>/dev/null
                        log "stop $svc (was $st)"
                else
                        log "absent svc $svc (no init.svc entry)"
                fi
        done
}

disable_apps() {
        for app in $FREEZEAPPS; do
                pm disable-until-used "$app" >/dev/null 2>&1 \
                        && log "disabled $app" \
                        || log "disable failed/absent $app"
        done
}

# Full DISABLED, for the android:persistent packages that survive disable-until-used (see DISABLEAPPS).
# A persistent package already running when the sweep reaches it keeps running until killed, and the
# disable only prevents the *next* launch, so each entry is force-stopped immediately after the state
# change rather than being left for stop_apps. Failures are logged rather than fatal: an absent package
# is expected here while the pasr package name is unresolved.
hard_disable_apps() {
        for app in $DISABLEAPPS; do
                if pm disable "$app" >/dev/null 2>&1; then
                        am force-stop "$app" >/dev/null 2>&1
                        log "disabled (full) $app"
                else
                        log "full-disable failed/absent $app"
                fi
        done
}

# Restores every package this script disables, for do_revert. PackageManager persists enabled-state
# across reboots and across removal of the module, so this is the one part of the configuration that a
# reboot does not undo on its own; without it, uninstalling the module would leave the device with
# packages disabled and no obvious route back.
enable_apps() {
        for app in $DISABLEAPPS $FREEZEAPPS; do
                pm enable "$app" >/dev/null 2>&1 \
                        && log "re-enabled $app" \
                        || log "re-enable failed/absent $app"
        done
}

stop_apps() {
        for app in $STOPAPPS; do
                # A package with no live process needs no force-stop. Skipping it avoids the binder round
                # trip and keeps the log a record of processes actually terminated rather than of sweep
                # attempts, which matters because this sweep runs repeatedly.
                if ! pidof "$app" >/dev/null 2>&1; then
                        continue
                fi
                am force-stop "$app" >/dev/null 2>&1 \
                        && log "force-stopped $app" \
                        || log "force-stop failed $app"
        done
}

# Rate-limited entry point for the STOPAPPS sweep, for callers that fire on device events rather than at
# boot.
#
# do_pcm formerly called stop_apps unconditionally on every inotify event. Because a PCM close and the
# following open are two events, an ordinary track transition ran the whole sweep twice: the 2026-09-29
# log shows fourteen force-stop calls within two seconds at 14:16 and again at 14:20, 14:12, 14:08 and
# 14:05. Several STOPAPPS members relaunch immediately after termination, so the result was a continuous
# kill-relaunch cycle for the duration of playback, at a cost in wakeups and heat disproportionate to any
# benefit, and one that regenerated the background processes the sweep exists to remove.
#
# The sweep is still wanted — these packages do return, by user interaction or on their own — so it is
# retained on PCM open only, with a minimum interval between runs. A timestamp in STATE_DIR (tmpfs)
# carries the last run, so the interval is enforced within an uptime and resets at boot, where do_boot's
# own unconditional sweep has already run.
stop_apps_ratelimited() {
        [ "$STOPAPPS_ON_PCM" = 1 ] || return 0
        stamp="$STATE_DIR/stopapps.last"
        now=$(date +%s 2>/dev/null) || return 0
        if [ -f "$stamp" ]; then
                last=$(cat "$stamp" 2>/dev/null)
                case "$last" in
                        ''|*[!0-9]*) last=0 ;;
                esac
                gap=$((now - last))
                if [ "$gap" -lt "$STOPAPPS_MIN_GAP" ]; then
                        return 0
                fi
        fi
        echo "$now" > "$stamp" 2>/dev/null
        stop_apps
}

# ---------------------------------------------------------------------------------------------------
# CPU / GPU baseline
# ---------------------------------------------------------------------------------------------------

# Writes a little-cluster frequency window [lo, hi] in kHz. The min is dropped to the idle floor first
# so a higher max can be applied without a transient min > max rejection, then the target min is set.
# Read-back is logged: it exposes any external floor assertion (cpu_boost / perf HAL / cpufreq-QoS)
# that snaps scaling_min_freq back up, which is an open investigation item.
set_little_freq() {
        lo=$1; hi=$2
        [ -d "$POLICY0" ] || { log "freq: $POLICY0 absent"; return 1; }
        echo "$FREQ_IDLE" > "$POLICY0/scaling_min_freq" 2>/dev/null
        echo "$hi"        > "$POLICY0/scaling_max_freq" 2>/dev/null
        echo "$lo"        > "$POLICY0/scaling_min_freq" 2>/dev/null
        read -r rbmin < "$POLICY0/scaling_min_freq" 2>/dev/null
        read -r rbmax < "$POLICY0/scaling_max_freq" 2>/dev/null
        [ "$rbmin" = "$lo" ] && [ "$rbmax" = "$hi" ] \
                || log "freq: WARN request min=$lo max=$hi readback min=$rbmin max=$rbmax (floor asserted?)"
}

# Point the DDR bandwidth devfreq devices at a static governor, when DDR_BW_GOV is set.
#
# Each matching device is checked against its own available_governors before the write, so an
# unsupported name is reported rather than silently failing. The read-back is logged for the same reason
# set_little_freq logs its own: a governor write can be accepted and then overridden by another client.
set_bus_governor() {
        [ -n "$DDR_BW_GOV" ] || return 0
        [ -d /sys/class/devfreq ] || { log "devfreq: no /sys/class/devfreq"; return 0; }
        found=0
        for dev in /sys/class/devfreq/*; do
                [ -f "$dev/governor" ] || continue
                case "${dev##*/}" in *"$DDR_BW_MATCH"*) : ;; *) continue ;; esac
                found=$((found + 1))
                avail=""; read -r avail < "$dev/available_governors" 2>/dev/null
                case " $avail " in
                        *" $DDR_BW_GOV "*) : ;;
                        *) log "devfreq: ${dev##*/} does not offer '$DDR_BW_GOV' (has: $avail)"; continue ;;
                esac
                was=""; read -r was < "$dev/governor" 2>/dev/null
                echo "$DDR_BW_GOV" 2>/dev/null > "$dev/governor"
                now=""; read -r now < "$dev/governor" 2>/dev/null
                if [ "$now" = "$DDR_BW_GOV" ]; then
                        log "devfreq: ${dev##*/} governor $was -> $now"
                else
                        log "devfreq: WARN ${dev##*/} governor still $now (wanted $DDR_BW_GOV, was $was)"
                fi
        done
        [ "$found" -gt 0 ] || log "devfreq: no device matching '$DDR_BW_MATCH'"
}

cpu_gpu_baseline() {
        set_little_freq "$FREQ_IDLE" "$FREQ_IDLE_MAX"
        echo 300000 > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq
        echo 652000 > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq
        if [ -w /sys/kernel/gpu/gpu_max_clock ]; then
                echo "$GPU_MAX" > /sys/kernel/gpu/gpu_max_clock 2>/dev/null && log "gpu_max_clock=$GPU_MAX"
        fi
        [ "$QUIET_LOGD" = 1 ] && setprop persist.log.tag E
        set_bus_governor
        log "baseline: little idle ${FREQ_IDLE}/${FREQ_IDLE_MAX}"
}

# ---------------------------------------------------------------------------------------------------
# cpuset partition
# ---------------------------------------------------------------------------------------------------

# Creates or re-parameterizes a cpuset at $1 with cpus=$2. mems must be populated before the set will
# accept tasks and is inherited from the root cpuset.
ensure_set() {
        p=$1; c=$2
        [ -d "$p" ] || mkdir "$p" 2>/dev/null
        [ -d "$p" ] || { log "ensure_set $p: mkdir failed"; return 1; }
        read -r pm < "$CPUSET/$MF"
        echo "$pm" > "$p/$MF" 2>/dev/null
        echo "$c"  > "$p/$CF" 2>/dev/null
        log "set ${p##*/} cpus=$c"
}

# Recursive retarget of every cpuset in the tree to the big cluster, excluding root (whose cpus may
# not be narrowed below the online set) and the two custom sets. Uniform assignment to $BIG keeps
# every child a subset of its parent regardless of walk order. Writing cpuset.cpus migrates the tasks
# already resident in the set, so a late boot catches everything present at that point. Stock cpus are
# snapshotted for live revert.
#
# Recursion under POSIX sh without local scope is safe here because a for-loop word list is expanded
# once at loop entry and held internally; the shared loop variable being clobbered by the recursive
# call does not corrupt the outer iteration.
retarget_tree() {
        d=$1
        case "$d" in
                "$CPUSET"|"$AUDIO_SET"|"$BIGSINK") : ;;
                *)
                        if [ -f "$d/$CF" ]; then
                                read -r cur < "$d/$CF"
                                [ -n "$cur" ] && echo "$d $cur" >> "$BAK"
                                echo "$BIG" > "$d/$CF" 2>/dev/null \
                                        && log "retarget ${d#$CPUSET/} -> $BIG" \
                                        || log "retarget ${d#$CPUSET/}: write failed"
                        fi ;;
        esac
        for sub in "$d"/*/; do
                [ -d "$sub" ] || continue
                retarget_tree "${sub%/}"
        done
}

# Moves root-resident userspace tasks to the bigs sink. Kernel threads (empty cmdline) are pinned by
# the kernel and are not cpuset-movable; they are skipped. This single pass is the heavy lifter: it
# evicts zygote, so subsequent app forks inherit the bigs without further action.
drain_root() {
        [ -d "$BIGSINK" ] || return
        n=0
        while read -r tid; do
                cmd=""; read -r cmd < "/proc/$tid/cmdline" 2>/dev/null
                [ -n "$cmd" ] || continue
                echo "$tid" > "$BIGSINK/$TF" 2>/dev/null && n=$((n + 1))
        done < "$CPUSET/$TF"
        log "drained ${n} root tasks -> bigsink"
}

# Optionally moves init (pid 1) to the bigs sink so its own future forks (service restarts) inherit
# the bigs. Incremental over drain_root, which already handles the app-spawn flood via zygote.
sink_init() {
        [ "$SINK_INIT" = 1 ] || return
        if [ -f "$BIGSINK/cgroup.procs" ]; then
                echo 1 > "$BIGSINK/cgroup.procs" 2>/dev/null && log "init (pid 1) -> bigsink (procs)"
        else
                echo 1 > "$BIGSINK/$TF" 2>/dev/null && log "init (pid 1) -> bigsink (task)"
        fi
}

# ---------------------------------------------------------------------------------------------------
# IRQ affinity sort
# ---------------------------------------------------------------------------------------------------

# The cpuset partition reaches only what a cpuset can hold. Of the threads found on the little cluster
# in the 2026-09-23 and 2026-09-26 captures, everything still there after the partition and the
# render-thread re-pin are kernel-side: 251 at allow=0-7, 33 per-cpu, and roughly 65 of those are
# threaded IRQ handlers free to land on any core, including during playback. drain_root and forkwatch
# skip them by design — a kernel thread has an empty cmdline and is not cpuset-movable — so interrupt
# affinity is the only remaining lever on little-cluster load.
#
# The placement found on-device is close to the inverse of the intent. The audio bus interrupts
# (SoundWire master and wake) were on the big cluster while general system noise — 32 SMMU fault
# handlers, thermal, storage, touchscreen, the volume wheel, USB and charger — ran on the littles. The
# operation implemented here is therefore a two-way sort rather than a blanket push to the bigs: the
# audio list is held on $LITTLE, everything else is pushed to $BIG, and the unresolved list is left
# untouched. See the IRQ_AUDIO_FRAGS / IRQ_ASIS_FRAGS block in the configuration section.
#
# No snapshot is taken for do_revert. smp_affinity is runtime sysfs and is re-derived from the device
# tree and driver defaults on every boot, so a reboot restores stock placement; this matches the
# treatment of the cpufreq writes and differs from the cpuset masks only because those are mutated
# live by the framework and so need a recorded baseline.

# Resolve an interrupt's action name. /proc/irq/<n>/ carries one SUBDIRECTORY per registered action,
# named for the action, alongside its regular files; the directory is therefore the name. Interrupts
# with no registered action have no such subdirectory and yield nothing. /sys/kernel/irq/<n>/actions is
# the fallback, which on a shared line is a comma-separated list — acceptable, since matching is by
# substring.
irq_name() {
        for a in /proc/irq/"$1"/*/; do
                [ -d "$a" ] || continue
                a=${a%/}
                printf '%s' "${a##*/}"
                return 0
        done
        a=""
        read -r a < "/sys/kernel/irq/$1/actions" 2>/dev/null
        [ -n "$a" ] || return 1
        printf '%s' "$a"
}

# Convert a cpu list ("0", "4-7", "1-3,6") to the hex bitmask /proc/irq/default_smp_affinity requires.
#
# That node is the one interrupt interface on this platform with no _list counterpart, so unlike
# smp_affinity_list it cannot be handed a range and a mask has to be built. Arithmetic is done in the
# shell rather than by shelling out, and the result is emitted without the 0x prefix, which the node
# rejects. A malformed component yields nothing and the caller skips the write.
cpulist_mask() {
        m=0
        IFS=,
        for part in $1; do
                case "$part" in
                        *-*) lo=${part%%-*}; hi=${part##*-} ;;
                        *)   lo=$part; hi=$part ;;
                esac
                case "$lo$hi" in ''|*[!0-9]*) unset IFS; return 1 ;; esac
                [ "$lo" -le "$hi" ] || { unset IFS; return 1; }
                i=$lo
                while [ "$i" -le "$hi" ]; do
                        m=$((m | (1 << i)))
                        i=$((i + 1))
                done
        done
        unset IFS
        printf '%x' "$m"
}

# Seed the default affinity every interrupt requested from now on inherits.
#
# pin_irqs can only reach interrupts that already exist. A driver whose device is probed later — the WLAN
# firmware on the first Wi-Fi enable, dwc3 on a cable, anything behind an on-demand HAL — requests its
# interrupt after boot and takes the default, which is the full online set. The WLAN contact-event
# interrupts alone carried roughly 180,000 counts on cpu0 in the 2026-09-26 capture, so this is not a
# marginal set. One write here covers all of them without a rescan.
#
# Existing interrupts are unaffected: the kernel copies this mask at request time and never re-reads it.
seed_default_affinity() {
        f=/proc/irq/default_smp_affinity
        [ -f "$f" ] || return 0
        msk=$(cpulist_mask "$IRQ_NOISE_CPUS") || { log "irq: cannot parse IRQ_NOISE_CPUS='$IRQ_NOISE_CPUS'"; return 1; }
        cur=""; read -r cur < "$f" 2>/dev/null
        echo "$msk" 2>/dev/null > "$f"
        new=""; read -r new < "$f" 2>/dev/null
        # Compared numerically: the kernel renders the mask zero-padded to the cpu count ("00000001"),
        # which never string-matches the minimal form written here.
        if [ "$((0x$new))" = "$((0x$msk))" ] 2>/dev/null; then
                log "irq: default affinity for future interrupts -> ${IRQ_NOISE_CPUS} (mask $new, was $cur)"
        else
                log "irq: WARN default affinity write rejected (wanted $msk, reads $new)"
        fi
}

# Confine unbound workqueue work to $WQ_CPUS.
#
# A workqueue item queued without a cpu affinity is executed by an unbound worker pool, whose workers
# appear as kworker/u<N>:<n> and are placed by the scheduler across the whole online set. The kernel
# exposes one global mask for those pools at /sys/devices/virtual/workqueue/cpumask; writing it applies
# to existing pools and to every pool created afterwards, so no rescan and no re-application is needed.
# Per-cpu workqueues (kworker/<cpu>:<n>) are unaffected by design, as their placement is the point.
#
# This is the counterpart of seed_default_affinity for deferred work rather than interrupts: the
# 2026-09-29 capture recorded 258 of 286 threads holding a 0-7 mask last running on cpu0-3, and the
# unbound pools are the portion of that reachable by a single documented write.
#
# The previous value is recorded in STATE_DIR so do_revert can restore it within the same uptime; the
# node's default is the full online set and a reboot restores it regardless.
confine_workqueues() {
        f=/sys/devices/virtual/workqueue/cpumask
        [ -n "$WQ_CPUS" ] || return 0
        [ -f "$f" ] || { log "wq: no $f; unbound workqueue confinement skipped"; return 0; }
        msk=$(cpulist_mask "$WQ_CPUS") || { log "wq: cannot parse WQ_CPUS='$WQ_CPUS'"; return 1; }
        cur=""; read -r cur < "$f" 2>/dev/null
        [ -d "$STATE_DIR" ] || mkdir -p "$STATE_DIR" 2>/dev/null
        [ -f "$STATE_DIR/wq.cpumask.bak" ] || printf '%s\n' "$cur" > "$STATE_DIR/wq.cpumask.bak" 2>/dev/null
        echo "$msk" 2>/dev/null > "$f"
        new=""; read -r new < "$f" 2>/dev/null
        # Compared numerically: the kernel renders the mask zero-padded to the cpu count, which never
        # string-matches the minimal form written here.
        if [ "$((0x$new))" = "$((0x$msk))" ] 2>/dev/null; then
                log "wq: unbound workqueues -> ${WQ_CPUS} (mask $new, was $cur)"
        else
                log "wq: WARN cpumask write rejected (wanted $msk, reads $new)"
        fi
}

# Restore the unbound workqueue cpumask recorded by confine_workqueues, for do_revert.
restore_workqueues() {
        f=/sys/devices/virtual/workqueue/cpumask
        b="$STATE_DIR/wq.cpumask.bak"
        [ -f "$f" ] && [ -f "$b" ] || return 0
        old=""; read -r old < "$b" 2>/dev/null
        [ -n "$old" ] || return 0
        echo "$old" 2>/dev/null > "$f"
        rm -f "$b" 2>/dev/null
        log "wq: unbound workqueue cpumask restored to $old"
}

# Substring match of the name $1 against the space-separated fragment list $2.
frag_match() {
        for fr in $2; do
                case "$1" in *"$fr"*) return 0 ;; esac
        done
        return 1
}

# Sort every named interrupt onto its target cluster.
#
# Two properties of the interface shape the loop. A write is not guaranteed to be accepted: a per-cpu
# interrupt rejects it with EIO, and a line whose hardware can only target one core rejects a mask that
# excludes it with EINVAL. Neither is an error here — the intended placement is simply unavailable —
# so every write is verified by read-back rather than trusted, and a rejection is counted and reported
# in aggregate instead of aborting the pass. And smp_affinity_list accepts a cpu list directly
# ("4-7"), so $AUDIO_CPUS and $IRQ_NOISE_CPUS are written verbatim and no hex mask is computed.
#
# Per-interrupt logging is limited to the audio list, which is small and whose placement is the
# substance of the change. The bulk of the sort is reported as counts, with the names of the rejected
# lines appended to one line so a rejection that is not a per-cpu interrupt remains visible.
#
# Passing "check" as $1 suppresses every write and turns the pass into a read-only comparison of the
# current placement against the intended one, setting DRIFT_N to the number of interrupts that no longer
# match. Passing "repin" does the same comparison but re-writes the affinity of each drifted interrupt
# back to its target; DRIFT_N then reflects how many were corrected, and DRIFT_NAMES includes the
# transition (e.g. "20-glink-native:1->0"). A rejected interrupt — one still at the online set, meaning
# the initial write never took — is excluded from the count in both modes.
#
# The drift exists because the placement does not hold: on the 2026-09-26 boot 97 writes were verified
# at 10:43:42, and roughly fifteen minutes later 93 of them read back as cpu0. The interrupts that were
# pushed to $BIG are the ones that drift; the two held on $LITTLE do not, since cpu0 is inside their
# mask. See maintain_slow for the caller.
pin_irqs() {
        mode=$1
        [ "$IRQ_SORT" = 1 ] || { [ "$mode" = check ] || log "irq: sort disabled (IRQ_SORT=0)"; return 0; }
        [ -d /proc/irq ] || { [ "$mode" = check ] || log "irq: no /proc/irq; sort skipped"; return 0; }
        [ "$mode" = check ] || seed_default_affinity
        nlit=0; nbig=0; nheld=0; nrej=0; nnamed=0; ndrift=0; rejected=""; drifted=""
        # The online cpu set, read fresh: a rejected write leaves the mask at this value, which is how
        # check mode tells a never-established placement from one that was established and then lost.
        ONLINE=""; read -r ONLINE < /sys/devices/system/cpu/online 2>/dev/null
        [ -n "$ONLINE" ] || ONLINE="0-${BIG##*-}"
        for d in /proc/irq/[0-9]*; do
                [ -f "$d/smp_affinity_list" ] || continue
                num=${d##*/}
                nm=$(irq_name "$num") || { nnamed=$((nnamed + 1)); continue; }
                if frag_match "$nm" "$IRQ_ASIS_FRAGS"; then
                        nheld=$((nheld + 1)); continue
                fi
                if frag_match "$nm" "$IRQ_AUDIO_FRAGS"; then want=$AUDIO_CPUS; else want=$IRQ_NOISE_CPUS; fi
                cur=""; read -r cur < "$d/smp_affinity_list" 2>/dev/null
                if [ "$mode" = check ] || [ "$mode" = repin ]; then
                        # An interrupt sitting at the full online set never accepted the write in the
                        # first place and is a rejection, not drift. Anything else that has left its
                        # target has been moved by something other than this script.
                        if [ "$cur" != "$want" ]; then
                                if [ "$cur" = "$ONLINE" ]; then
                                        nrej=$((nrej + 1))
                                elif [ "$mode" = repin ]; then
                                        echo "$want" 2>/dev/null > "$d/smp_affinity_list"
                                        after=""; read -r after < "$d/smp_affinity_list" 2>/dev/null
                                        if [ "$after" = "$want" ]; then
                                                ndrift=$((ndrift + 1))
                                                [ "$ndrift" -le 12 ] && drifted="${drifted}${drifted:+ }$num-$nm:$cur->$want"
                                        else
                                                nrej=$((nrej + 1))
                                        fi
                                else
                                        ndrift=$((ndrift + 1))
                                        [ "$ndrift" -le 12 ] && drifted="${drifted}${drifted:+ }$num-$nm:$cur"
                                fi
                        fi
                        continue
                fi
                if [ "$cur" != "$want" ]; then
                        # 2>/dev/null precedes the output redirection deliberately: redirections are
                        # applied left to right, and a failure to OPEN the target is reported by the
                        # shell at that point. Written the other way round, an EACCES on the open
                        # escapes to stderr before stderr has been silenced, which at boot is an
                        # unattributed line in whatever log init happens to be holding.
                        echo "$want" 2>/dev/null > "$d/smp_affinity_list"
                        cur=""; read -r cur < "$d/smp_affinity_list" 2>/dev/null
                fi
                if [ "$cur" = "$want" ]; then
                        if [ "$want" = "$AUDIO_CPUS" ]; then
                                nlit=$((nlit + 1)); log "irq: $num-$nm -> $AUDIO_CPUS (audio path)"
                        else
                                nbig=$((nbig + 1))
                        fi
                else
                        nrej=$((nrej + 1)); rejected="${rejected}${rejected:+ }$num-$nm"
                fi
        done
        if [ "$mode" = check ] || [ "$mode" = repin ]; then
                DRIFT_N=$ndrift; DRIFT_NAMES=$drifted
                return 0
        fi
        log "irq: sorted ${nbig} -> ${IRQ_NOISE_CPUS}, ${nlit} -> ${AUDIO_CPUS}; ${nheld} held as-found, ${nnamed} unclaimed, ${nrej} rejected"
        [ "$nrej" -gt 0 ] && log "irq: rejected (per-cpu or hardware-constrained): ${rejected}"
        return 0
}

# Affine the threaded interrupt handlers to the same target their interrupt was sorted onto.
#
# /proc/irq/<n>/smp_affinity_list places the INTERRUPT: it decides which core takes the hardware
# exception and runs the primary handler. A handler registered with request_threaded_irq does its work
# in a separate kernel thread named irq/<n>-<action>, and that thread's cpu affinity is an independent
# task property which the interrupt write does not set. Sorting the interrupts therefore left 62 such
# threads at the default 0-7 mask in the 2026-09-29 capture, free to run on the audio cores while the
# interrupt itself was correctly placed on cpu0.
#
# This also removes the reporting artefact recorded in HANDOFF.md section 1, where a threaded handler
# keeps a stale mask until it next fires and MODE=threads shows handlers on the littles while the
# interrupt sort is holding: the mask is now set directly rather than being inherited on the next
# execution.
#
# One pass over /proc is used rather than a lookup per interrupt. The thread name carries its interrupt
# number, so the target is resolved from the same fragment lists pin_irqs uses and the two cannot
# disagree. taskset is toybox's and takes a hex mask; a thread that rejects the write (kthreads bound by
# the driver at creation) is counted, not treated as an error. One-shot, at boot, with no daemon: a
# thread's affinity is not re-derived by the kernel once set.
pin_irq_threads() {
        [ "$IRQ_THREADS" = 1 ] || return 0
        command -v taskset >/dev/null 2>&1 || { log "irq-threads: no taskset; pass skipped"; return 0; }
        amsk=$(cpulist_mask "$AUDIO_CPUS") || return 1
        nmsk=$(cpulist_mask "$IRQ_NOISE_CPUS") || return 1
        nlit=0; nbig=0; nheld=0; nrej=0; rejected=""
        for c in /proc/[0-9]*/comm; do
                comm=""; read -r comm < "$c" 2>/dev/null
                case "$comm" in irq/[0-9]*) : ;; *) continue ;; esac
                pid=${c#/proc/}; pid=${pid%/comm}
                rest=${comm#irq/}                      # "<num>-<action>", or "<num>" with no action
                num=${rest%%-*}
                nm=$(irq_name "$num") || nm=${rest#*-}
                if frag_match "$nm" "$IRQ_ASIS_FRAGS"; then
                        nheld=$((nheld + 1)); continue
                fi
                if frag_match "$nm" "$IRQ_AUDIO_FRAGS"; then want=$amsk; else want=$nmsk; fi
                taskset -p "$want" "$pid" >/dev/null 2>&1
                # Verified by read-back rather than by exit status: a write may be accepted by the call
                # and then narrowed by the kernel to the thread's permitted set.
                got=$(taskset -p "$pid" 2>/dev/null); got=${got##* }
                if [ "$((0x$got))" = "$((0x$want))" ] 2>/dev/null; then
                        if [ "$want" = "$amsk" ]; then nlit=$((nlit + 1)); else nbig=$((nbig + 1)); fi
                else
                        nrej=$((nrej + 1)); rejected="${rejected}${rejected:+ }$comm"
                fi
        done
        log "irq-threads: ${nbig} -> ${IRQ_NOISE_CPUS}, ${nlit} -> ${AUDIO_CPUS}; ${nheld} held as-found, ${nrej} rejected"
        [ "$nrej" -gt 0 ] && log "irq-threads: rejected: ${rejected}"
        return 0
}

# Sort the remaining unconstrained kernel threads off the audio cores.
#
# pin_irq_threads covers the irq/<n>-* handlers and confine_workqueues covers the unbound worker pools.
# The 2026-09-30 capture, taken with both in effect, still recorded 223 threads holding the full 0-7
# mask, of which 298 rows landed on cpu1-3. The largest single block is the Qualcomm diagnostic driver's
# per-subsystem channel threads — DIAG_*, MODEM_*, LPASS_*, SENSORS_*, NPU_*, CDSP_*, WCNSS_*, 46 of
# them, nearly all last seen on cpu3 — followed by the 16 mdss rotator fence threads rot_fenceq_0_*, the
# RCU callback and grace-period threads, and the ext4/jbd2/mmc storage workers. None of these is on the
# render path and none is reachable by either of the two existing passes.
#
# SELECTION RULE: a thread is considered only when its current affinity mask equals the full online set.
# That single test does the work three exclusion lists would otherwise have to do, and does it from the
# kernel's own state rather than from a name:
#   - per-cpu kthreads (migration/N, ksoftirqd/N, cpuhp/N, kworker/N:MH) carry a single-cpu mask and are
#     passed over without needing to be named;
#   - a thread the driver bound at creation is likewise already narrowed and is left alone;
#   - threads this module placed on an earlier pass are narrowed too, so a second run is idempotent and
#     no pass can widen or relocate what another pass has set.
# The corollary is that this pass never narrows a thread that something else deliberately placed, which
# is the property that makes a sweep this broad a reasonable risk.
#
# Kworker/u* threads are sent to $WQ_CPUS rather than to $KTHREAD_CPUS, which closes the gap
# confine_workqueues leaves behind it: the global cpumask governs worker pools, and a worker already
# attached to a pool when the mask is written keeps the affinity it was created with. The same capture
# shows the write succeeding (ff -> f0) with 12 of 15 kworker/u16 threads still reading 0-7 half an hour
# later. One write plus one sweep covers both the existing workers and every worker created afterwards.
#
# $BIG is the default destination, not cpu0. The reasoning that made 4-7 wrong for interrupts does not
# carry over: an interrupt masked to a set with no online cpu loses the mask outright, whereas a task's
# mask is intersected with the online set on each placement decision and survives isolation. core_ctl
# isolates the big cluster under low load, so the cost here is latency on the sorted threads under a
# light workload, not loss of the placement — and cpu0 is already the interrupt sink, which is the one
# core that should not also absorb RCU and reclaim. KTHREAD_CPUS=0 and KTHREAD_SORT=0 are both available
# from the environment if that trade proves wrong.
#
# Not restored by do_revert, for the reason given above pin_irqs: no prior value is worth recording when
# the stock state is "unconstrained" and a reboot reaches it unconditionally.
pin_kthreads() {
        [ "$KTHREAD_SORT" = 1 ] || return 0
        [ -n "$KTHREAD_CPUS" ] || { log "kthreads: sort skipped (KTHREAD_CPUS empty)"; return 0; }
        command -v taskset >/dev/null 2>&1 || { log "kthreads: no taskset; pass skipped"; return 0; }
        smsk=$(cpulist_mask "$KTHREAD_CPUS") || { log "kthreads: cannot parse KTHREAD_CPUS='$KTHREAD_CPUS'"; return 1; }
        amsk=$(cpulist_mask "$AUDIO_CPUS") || return 1
        if [ -n "$WQ_CPUS" ]; then wmsk=$(cpulist_mask "$WQ_CPUS") || return 1; else wmsk=$smsk; fi
        ONLINE=""; read -r ONLINE < /sys/devices/system/cpu/online 2>/dev/null
        [ -n "$ONLINE" ] || ONLINE="0-${BIG##*-}"
        omsk=$(cpulist_mask "$ONLINE") || return 1
        nsink=0; nlit=0; nwq=0; nheld=0; nskip=0; nrej=0; rejected=""
        for c in /proc/[0-9]*/comm; do
                pid=${c#/proc/}; pid=${pid%/comm}
                # A kernel thread has an empty cmdline. The file is READ rather than size-tested: every
                # procfs file reports a size of zero, so [ -s /proc/<pid>/cmdline ] is false for a
                # userspace process as well and would sweep the entire process table. Readability is
                # checked first for the same class of reason — an unreadable cmdline also reads as
                # empty, so without the guard a non-root invocation would classify every process it
                # cannot inspect as a kernel thread.
                [ -r "/proc/$pid/cmdline" ] || continue
                cl=""; read -r cl < "/proc/$pid/cmdline" 2>/dev/null
                [ -z "$cl" ] || continue
                comm=""; read -r comm < "$c" 2>/dev/null
                [ -n "$comm" ] || continue
                # Threaded interrupt handlers belong to pin_irq_threads, which resolves their target from
                # the interrupt lists. Excluded here so the two passes cannot disagree about one thread.
                case "$comm" in irq/[0-9]*) continue ;; esac
                if frag_match "$comm" "$KTHREAD_ASIS_FRAGS"; then
                        nheld=$((nheld + 1)); continue
                fi
                cur=$(taskset -p "$pid" 2>/dev/null); cur=${cur##* }
                [ -n "$cur" ] || continue
                if [ "$((0x$cur))" != "$((0x$omsk))" ] 2>/dev/null; then
                        nskip=$((nskip + 1)); continue
                fi
                case "$comm" in
                        kworker/u*) want=$wmsk; kind=wq ;;
                        *) if frag_match "$comm" "$KTHREAD_AUDIO_FRAGS"; then
                                   want=$amsk; kind=audio
                           else
                                   want=$smsk; kind=sink
                           fi ;;
                esac
                taskset -p "$want" "$pid" >/dev/null 2>&1
                # Verified by read-back rather than by exit status, as in pin_irq_threads: the call may
                # succeed and the kernel then narrow the result to the thread's permitted set.
                got=$(taskset -p "$pid" 2>/dev/null); got=${got##* }
                if [ "$((0x$got))" = "$((0x$want))" ] 2>/dev/null; then
                        case "$kind" in
                                wq)    nwq=$((nwq + 1)) ;;
                                audio) nlit=$((nlit + 1)); log "kthreads: $comm ($pid) -> $AUDIO_CPUS (audio path)" ;;
                                *)     nsink=$((nsink + 1)) ;;
                        esac
                else
                        nrej=$((nrej + 1))
                        [ "$nrej" -le 12 ] && rejected="${rejected}${rejected:+ }$comm"
                fi
        done
        log "kthreads: ${nsink} -> ${KTHREAD_CPUS}, ${nlit} -> ${AUDIO_CPUS}, ${nwq} kworker/u* -> ${WQ_CPUS:-$KTHREAD_CPUS}; ${nheld} held as-found, ${nskip} already constrained, ${nrej} rejected"
        [ "$nrej" -gt 0 ] && log "kthreads: rejected (first 12): ${rejected}"
        return 0
}

# Placement report, for the acceptance check of issue #8 and for any later re-identification pass.
# Prints one row per interrupt: number, action name, requested affinity, effective affinity, and the
# per-core counts from /proc/interrupts. The counts are what distinguish an interrupt that was moved
# from one that never fires — a static row is inert wherever it is placed. Rows come out in glob order
# (1, 10, 100, 11, ...) rather than numeric order; sort the output if that matters.
irq_report() {
        for d in /proc/irq/[0-9]*; do
                [ -f "$d/smp_affinity_list" ] || continue
                num=${d##*/}
                nm=$(irq_name "$num") || nm="(no action)"
                aff=""; read -r aff < "$d/smp_affinity_list" 2>/dev/null
                eff=""
                [ -f "$d/effective_affinity_list" ] && read -r eff < "$d/effective_affinity_list" 2>/dev/null
                cnt=$(awk -v key="${num}:" '$1 == key {
                        out = ""
                        for (k = 2; k <= NF && $k ~ /^[0-9]+$/; k++) out = out " " $k
                        print out; exit
                }' /proc/interrupts 2>/dev/null)
                printf '%-5s %-20s aff=%-8s eff=%-8s%s\n' "$num" "$nm" "${aff:-?}" "${eff:--}" "$cnt"
        done
}

# Interrupt RATE over an interval, per interrupt and per core, busiest first.
#
# irq_report prints cumulative counts, which answer "has this ever fired" but not "is it firing now".
# Every remaining question on this device is a rate question: whether a governor change reduced the RPM
# traffic, whether an interrupt is busy during playback or only during boot, whether a disabled device
# actually went quiet. A cumulative count cannot distinguish 100,000 interrupts during boot from 100,000
# per minute ever since.
#
# Two snapshots of /proc/interrupts and a difference. Rows whose delta is zero are omitted, which
# collapses the 153-interrupt table to the handful that are actually doing anything. Sorting is delegated
# to sort(1) rather than done in awk, since this platform's awk has no array-sort primitive.
irq_rate() {
        secs="${1:-30}"
        case "$secs" in ''|*[!0-9]*) echo "irqrate: interval must be a whole number of seconds" >&2; return 2 ;; esac
        mkdir -p "$STATE_DIR" 2>/dev/null
        s1="$STATE_DIR/irqrate.1"; s2="$STATE_DIR/irqrate.2"
        cat /proc/interrupts > "$s1" 2>/dev/null || { echo "irqrate: cannot read /proc/interrupts" >&2; return 1; }
        sleep "$secs"
        cat /proc/interrupts > "$s2" 2>/dev/null
        echo "interrupts over ${secs}s — rate/s, total, irq, source, then per-core deltas"
        awk -v secs="$secs" '
        # First file: baseline. The header line names the cpus, so its field count is the cpu count.
        NR == FNR {
                if (FNR == 1) { ncpu = NF; next }
                k = $1; sub(":", "", k)
                if (k ~ /^[0-9]+$/) for (i = 1; i <= ncpu; i++) base[k, i] = $(i + 1)
                next
        }
        FNR == 1 { next }
        {
                k = $1; sub(":", "", k)
                if (k !~ /^[0-9]+$/) next
                tot = 0; per = ""
                for (i = 1; i <= ncpu; i++) {
                        d = $(i + 1) - base[k, i]
                        if (d < 0) d = 0          # counter reset or a cpu that came online mid-interval
                        tot += d
                        per = per sprintf(" %7d", d)
                }
                if (tot == 0) next
                desc = ""
                for (i = ncpu + 2; i <= NF; i++) desc = desc " " $i
                printf "%9.1f %9d  irq %-4s %-34s %s\n", tot / secs, tot, k, substr(desc, 2), per
        }' "$s1" "$s2" | sort -rn
        rm -f "$s1" "$s2"
}

# ---------------------------------------------------------------------------------------------------
# Audio render-thread placement (pcm entry)
# ---------------------------------------------------------------------------------------------------

# Render-path thread comms (truncated to 15 chars) held on the little cluster.
audio_match() {
        case "$1" in
                ExoPlayer:Playb*|ExoPlayer:Simp*|AudioTrack*|AudioEngine*) return 0 ;;
                *) return 1 ;;
        esac
}

# audioserver mixer/output threads, moved only when INCLUDE_AUDIOSERVER=1 (highest underrun risk if
# the little cluster is later frequency-capped).
#
# FastMixer and writer were removed on 2026-09-24. A full enumeration of audioserver's threads on this
# build (13 of them: the main thread, DeviceEffectMan, ApmAudio, ApmOutput, TimerThread, seven binder
# threads, and AudioOut_D) contains neither. FastMixer does not exist on this build at all; writer
# exists, but belongs to the audio HAL process, which audiohal_match covers. AudioOut* is therefore the
# only pattern that ever fires here, and it matches exactly one thread.
audioserver_match() {
        case "$1" in
                AudioOut*) return 0 ;;
                *) return 1 ;;
        esac
}

# Audio HAL output thread. The HAL's "writer" thread is the last userspace stage of the render path —
# it hands PCM to the kernel driver, downstream of both the app's render threads and audioserver's
# AudioOut_D — and was left on the big cluster by every earlier version, under the policy4 ceiling, and
# observed migrating between big cores between captures. Confirmed on-device 2026-09-24: pinning it to
# the littles holds and is audibly acceptable.
#
# Unlike the app's render threads, this one is long-lived. The same tid (3147) persisted across track
# changes and stream restarts in three separate captures, where the app's AudioTrack and ExoPlayer
# threads were torn down and recreated each time. The HAL is also a native init service, so it is not
# subject to the cgroup.procs re-assignment that evicts the app process; once placed it stays placed,
# and the periodic pass over it is a cheap no-op that exists only to recover from a HAL restart.
audiohal_match() {
        case "$1" in
                writer*) return 0 ;;
                *) return 1 ;;
        esac
}

# Resolve the audio HAL's pid, memoised in STATE_DIR across invocations.
#
# The HAL is addressed by process comm rather than by a binder service name: "audio.service" is a comm,
# not a name servicemanager knows, so neither `service check` nor `dumpsys` resolves it. pidof is tried
# first and a /proc scan is the fallback, because a comm is capped at 15 characters and may be a
# truncation that pidof cannot match.
#
# The cache is validated before use — the pid must still exist and still carry the expected comm — so a
# HAL restart that reuses a pid cannot leave the wrong process pinned. The file is deliberately not
# named *.pid: STATE_DIR's pidfiles hold daemons that do_revert kills, and this is a foreign process
# that must never be killed.
audiohal_pid() {
        hp=""
        if [ -f "$AUDIOHAL_TARGET" ]; then
                read -r hp < "$AUDIOHAL_TARGET" 2>/dev/null
                if [ -n "$hp" ] && [ -d "/proc/$hp" ]; then
                        hc=""; read -r hc < "/proc/$hp/comm" 2>/dev/null
                        [ "$hc" = "$AUDIOHAL_COMM" ] && { printf '%s' "$hp"; return 0; }
                fi
                hp=""
        fi
        hp=$(pidof "$AUDIOHAL_COMM" 2>/dev/null | cut -d' ' -f1)
        if [ -z "$hp" ]; then
                for d in /proc/[0-9]*; do
                        hc=""; read -r hc < "$d/comm" 2>/dev/null || continue
                        [ "$hc" = "$AUDIOHAL_COMM" ] || continue
                        hp=${d##*/}; break
                done
        fi
        [ -n "$hp" ] || return 1
        echo "$hp" > "$AUDIOHAL_TARGET" 2>/dev/null
        printf '%s' "$hp"
}

# DSD detection via the codec sysfs stream_type attribute, when present.
is_dsd() {
        st=/sys/devices/virtual/codec/codec0/stream_type
        [ -r "$st" ] || return 1
        read -r v < "$st" 2>/dev/null || return 1
        case "$v" in *[Dd][Ss][Dd]*) return 0 ;; *) return 1 ;; esac
}

# rate (Hz) [+ dsd flag] -> little-cluster tier (kHz).
map_freq() {
        r=$1; dsd=$2
        [ "$dsd" = 1 ] && { echo "$FREQ_ULTRA"; return; }
        [ -n "$r" ] || { echo "$FREQ_STD"; return; }
        if   [ "$r" -le 48000 ];  then echo "$FREQ_STD"
        elif [ "$r" -le 192000 ]; then echo "$FREQ_HIRES"
        else                            echo "$FREQ_ULTRA"; fi
}

# Re-derives stream state and rate from hw_params. The open() ioctl sequence populates hw_params
# slightly after the inotify open event, so a brief settle plus retries avoids reading an
# as-yet-unconfigured stream. Sets HW_STATE (open|closed) and HW_RATE.
read_hw() {
        HW_STATE=closed; HW_RATE=""
        i=0
        while [ "$i" -lt 3 ]; do
                read -r first < "$HWP" 2>/dev/null || first="closed"
                case "$first" in
                        closed*|"") HW_STATE=closed; return ;;
                        *)
                                HW_STATE=open
                                while read -r k v _; do
                                        [ "$k" = "rate:" ] && { HW_RATE=$v; break; }
                                done < "$HWP"
                                [ -n "$HW_RATE" ] && return ;;
                esac
                i=$((i + 1)); sleep 0.2
        done
}

# Moves the identified render threads into the audio cpuset.
#
# Sets two globals rather than logging directly, so the same pass serves both the one-shot pcm handler
# and the re-pin daemon: MOVED_N is the number of matched threads written to the set, RECLAIMED_N the
# subset of those that were resident somewhere else at the start of the pass. RECLAIMED_N is the
# eviction signal — under a steady state where nothing displaces the render path it stays 0, and any
# non-zero value is a direct record that the threads were moved out from under the set since the last
# pass. Reading /proc/<tid>/cpuset costs one extra read for each of the ~5 matched threads.
#
# Passing "quiet" as $1 suppresses the summary line; callers that want it log from MOVED_N themselves.
#
# PROC_CTX records the player's PROCESS-level cpuset and oom_score_adj, sampled once per pass before
# any thread is written. Thread-level state alone cannot distinguish the two ways a render thread
# leaves the set: a per-thread write to some other set's tasks file, versus a whole-process migration
# by system_server writing the pid to a stock set's cgroup.procs. The latter leaves the process cpuset
# reading /top-app, /foreground or /background rather than /, and is accompanied by an oom_score_adj
# change, since both are driven by the same process-state transition in ActivityManagerService. Two
# reads per pass, logged only alongside a non-zero RECLAIMED_N.
move_audio() {
        [ -d "$AUDIO_SET" ] || ensure_set "$AUDIO_SET" "$AUDIO_CPUS"
        aset=${AUDIO_SET##*/}
        n=0; rec=0
        PROC_CTX=""
        for p in $(pidof "$MUSICPKG" 2>/dev/null); do
                pcs=""; read -r pcs < "/proc/$p/cpuset" 2>/dev/null
                poom=""; read -r poom < "/proc/$p/oom_score_adj" 2>/dev/null
                PROC_CTX="${PROC_CTX}${PROC_CTX:+ }pid=${p} cpuset=${pcs:-?} oom=${poom:-?}"
                for t in /proc/"$p"/task/*; do
                        [ -d "$t" ] || continue
                        read -r comm < "$t/comm" 2>/dev/null || continue
                        audio_match "$comm" || continue
                        cs=""; read -r cs < "$t/cpuset" 2>/dev/null
                        [ "$cs" = "/$aset" ] || rec=$((rec + 1))
                        echo "${t##*/}" > "$AUDIO_SET/$TF" 2>/dev/null && n=$((n + 1))
                done
        done
        if [ "$INCLUDE_AUDIOSERVER" = 1 ]; then
                for p in $(pidof audioserver 2>/dev/null); do
                        for t in /proc/"$p"/task/*; do
                                [ -d "$t" ] || continue
                                read -r comm < "$t/comm" 2>/dev/null || continue
                                audioserver_match "$comm" || continue
                                cs=""; read -r cs < "$t/cpuset" 2>/dev/null
                                [ "$cs" = "/$aset" ] || rec=$((rec + 1))
                                echo "${t##*/}" > "$AUDIO_SET/$TF" 2>/dev/null && n=$((n + 1))
                        done
                done
        fi
        if [ "$INCLUDE_AUDIOHAL" = 1 ]; then
                hp=$(audiohal_pid) || hp=""
                if [ -n "$hp" ]; then
                        for t in /proc/"$hp"/task/*; do
                                [ -d "$t" ] || continue
                                read -r comm < "$t/comm" 2>/dev/null || continue
                                audiohal_match "$comm" || continue
                                cs=""; read -r cs < "$t/cpuset" 2>/dev/null
                                [ "$cs" = "/$aset" ] || rec=$((rec + 1))
                                echo "${t##*/}" > "$AUDIO_SET/$TF" 2>/dev/null && n=$((n + 1))
                        done
                elif [ "$1" != quiet ]; then
                        log "audio-hal: no process with comm '${AUDIOHAL_COMM}' (set AUDIOHAL_COMM)"
                fi
        fi
        MOVED_N=$n; RECLAIMED_N=$rec
        [ "$1" = quiet ] || log "audio-set: ${n} threads on ${AUDIO_CPUS}"
}

# ---------------------------------------------------------------------------------------------------
# Serialization lock for overlapping pcm events
# ---------------------------------------------------------------------------------------------------

acquire_lock() {
        mkdir -p "$STATE_DIR" 2>/dev/null
        i=0
        while ! mkdir "$LOCKDIR" 2>/dev/null; do
                i=$((i + 1)); [ "$i" -ge 20 ] && break   # ~2 s bound; proceed on a presumed stale holder
                sleep 0.1
        done
        trap release_lock EXIT INT TERM
}

release_lock() { rmdir "$LOCKDIR" 2>/dev/null; }

# ---------------------------------------------------------------------------------------------------
# Subcommand: pcm (per inotifyd event)
# ---------------------------------------------------------------------------------------------------

do_pcm() {
        detect_files
        acquire_lock
        read_hw
        if [ "$HW_STATE" = open ]; then
                dsd=0; is_dsd && dsd=1
                f=$(map_freq "$HW_RATE" "$dsd")
                move_audio                            # first pass
                sleep 0.2
                move_audio                            # second pass captures late-spawning render threads
                set_little_freq "$f" "$f"             # constant frequency at the tier setpoint while playing
                log "pcm open rate=${HW_RATE} dsd=${dsd} -> little=${f}"
                # Rate-limited, and on open only. See the comment above stop_apps_ratelimited for why an
                # unconditional call here ran the sweep twice per track transition.
                stop_apps_ratelimited
        else
                set_little_freq "$FREQ_IDLE" "$FREQ_IDLE_MAX"
                log "pcm closed -> little idle ${FREQ_IDLE}/${FREQ_IDLE_MAX}"
        fi
        release_lock
}

# ---------------------------------------------------------------------------------------------------
# Subcommand: forkwatch (persistent) and maintslow (persistent alternative)
# ---------------------------------------------------------------------------------------------------

detect_trace() {
        for base in /sys/kernel/tracing /sys/kernel/debug/tracing; do
                [ -d "$base/events/sched/sched_process_fork" ] && { TBASE=$base; return 0; }
        done
        return 1
}

# Blocks on a sched_process_fork trace_pipe in a private ftrace instance (isolated ring buffer and
# event state; teardown is rmdir). The read sleeps in-kernel until a fork is recorded, so idle cost is
# nil. A child is re-drained only if it landed in the root cpuset; anything already confined by
# inheritance is skipped. The child comm is deliberately not matched here because at fork time it still
# carries the parent name.
do_forkwatch() {
        detect_files
        [ -d "$BIGSINK" ] || ensure_set "$BIGSINK" "$BIG"
        detect_trace || { log "forkwatch: no tracefs; switching to maintslow"; maintain_slow; return; }
        TINST="$TBASE/instances/dx180"
        if mkdir "$TINST" 2>/dev/null || [ -d "$TINST" ]; then
                EVDIR="$TINST/events/sched/sched_process_fork"; PIPE="$TINST/trace_pipe"
        else
                log "forkwatch: trace instances unsupported; using global buffer"
                EVDIR="$TBASE/events/sched/sched_process_fork"; PIPE="$TBASE/trace_pipe"
                echo 1 > "$TBASE/tracing_on" 2>/dev/null
        fi
        echo 1 > "$EVDIR/enable" 2>/dev/null \
                || { log "forkwatch: cannot enable fork event; switching to maintslow"; maintain_slow; return; }
        log "forkwatch: blocking on $PIPE"
        exec 3< "$PIPE"
        while IFS= read -r line <&3; do
                case "$line" in *child_pid=*) ;; *) continue ;; esac
                c=${line##*child_pid=}; c=${c%% *}
                case "$c" in ''|*[!0-9]*) continue ;; esac
                read -r cs < "/proc/$c/cpuset" 2>/dev/null || continue
                [ "$cs" = "/" ] || continue                 # already confined by inheritance
                cmd=""; read -r cmd < "/proc/$c/cmdline" 2>/dev/null
                [ -n "$cmd" ] || continue                   # kernel thread, not cpuset-movable
                echo "$c" > "$BIGSINK/$TF" 2>/dev/null
        done
}

# Coarse backstop: scans the root cpuset only, at a wide interval. Appropriate when SINK_INIT=1 leaves
# the root cpuset nearly empty and per-fork wakeups are unwarranted.
maintain_slow() {
        detect_files
        [ -d "$BIGSINK" ] || ensure_set "$BIGSINK" "$BIG"
        log "maintslow: root-scan every ${INTERVAL}s"
        last_drift=-1
        while :; do
                sleep "$INTERVAL"
                while read -r tid; do
                        cmd=""; read -r cmd < "/proc/$tid/cmdline" 2>/dev/null
                        [ -n "$cmd" ] && echo "$tid" > "$BIGSINK/$TF" 2>/dev/null
                done < "$CPUSET/$TF"
                # Drift check on the boot-time IRQ sort, riding the pass that is already running
                # rather than adding a fourth daemon.
                #
                # When IRQ_DRIFT_REPIN=1, drifted interrupts are re-written to their intended target
                # and the count reflects how many were corrected. This is the counterpart to pinwatch
                # for the render threads: the kernel (suspend path, irq_set_affinity_hint in the glink
                # driver) re-affines certain interrupts, and repeated re-application from userspace is
                # the only available remedy. The primary target is glink-native (IRQ 20), which drifts
                # from cpu0 to cpu1 approximately 65 s after boot and does not return on its own.
                #
                # When IRQ_DRIFT_REPIN=0, the check is read-only as before.
                #
                # A line is emitted only when the count CHANGES, so the onset and the progression are
                # timestamped and a settled state is silent. Without that, a drift that never resolves
                # would log once per interval forever.
                if [ "$IRQ_DRIFT_CHECK" = 1 ] && [ "$IRQ_SORT" = 1 ]; then
                        if [ "$IRQ_DRIFT_REPIN" = 1 ]; then
                                pin_irqs repin
                        else
                                pin_irqs check
                        fi
                        if [ "$DRIFT_N" != "$last_drift" ]; then
                                if [ "$DRIFT_N" -gt 0 ] 2>/dev/null; then
                                        if [ "$IRQ_DRIFT_REPIN" = 1 ]; then
                                                log "irq: re-pinned ${DRIFT_N} drifted interrupts [${DRIFT_NAMES}]"
                                        else
                                                log "irq: ${DRIFT_N} interrupts have left their target [${DRIFT_NAMES}]"
                                        fi
                                elif [ "$last_drift" -gt 0 ] 2>/dev/null; then
                                        log "irq: drift cleared; all sorted interrupts back on target"
                                fi
                                last_drift=$DRIFT_N
                        fi
                fi
        done
}

# Re-pins the render threads at a short interval for as long as the PCM is held open.
#
# The pcm handler alone does not hold the placement. system_server re-assigns an app on every
# process-state change by writing its pid to the cgroup.procs of a stock cpuset, and a cgroup.procs
# write migrates every thread in the process — so a single state change evicts the whole render path
# from the audio set at once. retarget_tree points the stock sets at the big cluster, so the evicted
# threads land there and stay until the next PCM event. The 2026-09-23 capture caught exactly this:
# all 65 app threads at allow=4-7 with only audioserver's AudioOut_D still on the littles, minutes
# after a pcm-open had logged five threads moved. audioserver survives because it is a native init
# service and is never subject to framework re-assignment.
#
# Re-application is the only remedy available from userspace. A cpuset migration overwrites the task's
# affinity mask, so sched_setaffinity cannot survive the move either; and the stock sets cannot simply
# be widened to include the littles without handing the little cluster back to every other app, which
# is the thing the partition exists to prevent.
#
# A pass is idempotent and cheap: it reads comm for the threads of two processes and writes only the
# tids that match, so a pass that changes nothing is a few dozen reads. A line is logged only when
# RECLAIMED_N is non-zero, so steady-state playback is silent in the log and every logged line is a
# recorded eviction. That makes the fix its own instrument: the frequency and timing of those lines
# answer whether eviction tracks app state changes or some other cadence, without a separate probe.
#
# The first populating pass of a stream is reported separately. Every matched thread is legitimately
# outside the set before anything has placed it, so that pass yields RECLAIMED_N == MOVED_N and is
# indistinguishable from a total eviction unless it is labelled. The 2026-09-24 11:16:20 log line
# ("reclaimed 5 of 5", one second ahead of the pcm-open handler) was such a pass and was read as an
# eviction. PLACED gates the label and resets on pcm-close, so each stream reports one placement and
# every later line is an eviction.
do_pinwatch() {
        detect_files
        PLACED=0
        log "pinwatch: re-pin every ${PIN_INTERVAL}s while the PCM is open"
        while :; do
                read_hw
                if [ "$HW_STATE" = open ]; then
                        move_audio quiet
                        if [ "$RECLAIMED_N" -gt 0 ] 2>/dev/null; then
                                if [ "$PLACED" = 0 ]; then
                                        log "pinwatch: placed ${MOVED_N} render threads (stream start)"
                                else
                                        log "pinwatch: reclaimed ${RECLAIMED_N} of ${MOVED_N} render threads [${PROC_CTX:-no player}]"
                                fi
                        fi
                        [ "$MOVED_N" -gt 0 ] 2>/dev/null && PLACED=1
                else
                        PLACED=0
                fi
                sleep "$PIN_INTERVAL"
        done
}

# ---------------------------------------------------------------------------------------------------
# Daemon launch (from boot) and node wait
# ---------------------------------------------------------------------------------------------------

wait_for_node() {
        i=0
        while [ ! -e "$1" ]; do
                i=$((i + 1)); [ "$i" -ge 50 ] && return 1   # ~10 s
                sleep 0.2
        done
}

# Backgrounded launch (prototype). Children reparent to init when boot exits; they do NOT auto-restart
# on death. The production form is a module system/etc/init/*.rc service with a seclabel, where init
# restarts the daemon. pidfiles enable a clean live revert.
# Confirms a backgrounded child is still alive a moment after launch, and logs the outcome truthfully.
#
# The previous form logged "<name> launched" unconditionally, from the parent, immediately after the
# fork. A child that failed to exec produced an identical log line to one that started correctly,
# which is how a completely dead module came to look healthy in the log for 45 minutes. The short
# settle is deliberate: an exec failure surfaces within milliseconds, so this distinguishes the two
# cases without waiting on anything.
confirm_daemon() {
        name=$1; dpid=$2
        sleep 0.3
        if kill -0 "$dpid" 2>/dev/null; then
                log "$name launched (pid $dpid)"
                return 0
        fi
        log "$name FAILED to start (pid $dpid exited immediately; check the execute bit on $SELF)"
        return 1
}

# The two long-running daemons are started through an explicit interpreter rather than by executing
# $SELF. See ensure_self_exec: the execute bit on this file is not reliably present, and invoking the
# interpreter directly removes the dependency for everything except inotifyd, which must exec the
# program it is given and therefore still requires it.
# Kill any daemon this module has already started, from its pidfile, and report what was found.
#
# do_boot is documented as run-once from service.sh, but it is also the only way to apply a configuration
# change without rebooting — `AUDIO_CPUS=1-3 sh dx180quiet.sh boot` is the intended way to test a setting,
# and that means a second do_boot on an already-configured system is a normal operation rather than a
# mistake. Without this, each such run orphans the previous generation: launch_daemons spawns a fresh
# maintslow, inotifyd and pinwatch and overwrites the pidfiles, so the earlier ones keep running with no
# recorded pid and survive do_revert entirely. Two pinwatch loops re-pin every PIN_INTERVAL against each
# other, and two inotifyd watchers fire the pcm handler twice per PCM event, where the second is
# serialized behind the first by the lock and costs a full pass to conclude nothing changed.
#
# A missing pidfile, a stale pid, and a pid that has been recycled by an unrelated process are all
# indistinguishable here, so the comm is checked before the kill: every daemon of this module is an
# interpreter running this script, so anything whose comm is not the shell's basename is left alone.
stop_daemons() {
        killed=0
        for pf in maint inotifyd pinwatch wifigated; do
                [ -f "$STATE_DIR/$pf.pid" ] || continue
                pp=""; read -r pp < "$STATE_DIR/$pf.pid" 2>/dev/null
                case "$pp" in ''|*[!0-9]*) rm -f "$STATE_DIR/$pf.pid"; continue ;; esac
                [ -d "/proc/$pp" ] || { rm -f "$STATE_DIR/$pf.pid"; continue; }
                pc=""; read -r pc < "/proc/$pp/comm" 2>/dev/null
                case "$pc" in
                        "${SHELL_BIN##*/}"|inotifyd|mksh|sh) : ;;
                        # The pidfile is deliberately LEFT in place here. The pid belongs to something
                        # else, so the daemon it named is either gone or untracked, and the recorded value
                        # is the only remaining evidence of either. launch_daemons overwrites it moments
                        # later in the boot path, so nothing is leaked; in the revert path it survives for
                        # a human to look at.
                        *) log "daemons: $pf pid $pp is now '$pc'; not killing"; continue ;;
                esac
                rm -f "$STATE_DIR/$pf.pid"
                kill "$pp" 2>/dev/null && { killed=$((killed + 1)); log "daemons: killed previous $pf ($pp)"; }
        done
        [ "$killed" -eq 0 ] || log "daemons: ${killed} daemon(s) from an earlier run stopped before relaunch"
}

launch_daemons() {
        stop_daemons
        case "$MAINT" in
                slow) "$SHELL_BIN" "$SELF" maintslow >/dev/null 2>&1 & mpid=$!
                      echo "$mpid" > "$STATE_DIR/maint.pid"; confirm_daemon maintslow "$mpid" ;;
                *)    "$SHELL_BIN" "$SELF" forkwatch >/dev/null 2>&1 & mpid=$!
                      echo "$mpid" > "$STATE_DIR/maint.pid"; confirm_daemon forkwatch "$mpid" ;;
        esac
        if wait_for_node "$PCM_NODE"; then
                inotifyd "$SELF" "$PCM_NODE" >/dev/null 2>&1 & ipid=$!
                echo "$ipid" > "$STATE_DIR/inotifyd.pid"
                confirm_daemon inotifyd "$ipid" && log "inotifyd watching $PCM_NODE"
        else
                log "PCM node $PCM_NODE absent after timeout; inotifyd not started"
        fi
        if [ "$PINWATCH" = 1 ]; then
                "$SHELL_BIN" "$SELF" pinwatch >/dev/null 2>&1 & ppid_=$!
                echo "$ppid_" > "$STATE_DIR/pinwatch.pid"; confirm_daemon pinwatch "$ppid_"
        fi
        if [ "$WIFI_GATE" = 1 ]; then
                "$SHELL_BIN" "$SELF" wifigated >/dev/null 2>&1 & wpid=$!
                echo "$wpid" > "$STATE_DIR/wifigated.pid"; confirm_daemon wifigated "$wpid"
        fi
}

# ---------------------------------------------------------------------------------------------------
# Subcommand: wifigated (persistent, opt-in via WIFI_GATE=1)
# ---------------------------------------------------------------------------------------------------

# Returns 0 if the display is interactive (screen on), 1 if not.
#
# Uses the power-management wakefulness state from dumpsys, which distinguishes screen-on from
# screen-off regardless of lock state. The alternative — reading a backlight brightness node — is
# cheaper but unreliable on devices that use an always-on display or have no exported brightness node.
#
# dumpsys power is a single binder call and returns quickly. The output is parsed for mWakefulness,
# which reads "Awake" when the screen is on and "Asleep" or "Dozing" when off.
is_screen_on() {
        _ws=$(dumpsys power 2>/dev/null | grep 'mWakefulness=' | head -1)
        case "$_ws" in
                *Awake*) return 0 ;;
                *)       return 1 ;;
        esac
}

# Reads the current rx+tx byte count for the configured wifi interface. Prints the sum to stdout.
# Returns 1 if the interface is absent (wifi already disabled or the driver is unloaded).
wifi_traffic_bytes() {
        _rx=0; _tx=0
        [ -f "/sys/class/net/${WIFI_IFACE}/statistics/rx_bytes" ] || return 1
        read -r _rx < "/sys/class/net/${WIFI_IFACE}/statistics/rx_bytes" 2>/dev/null
        read -r _tx < "/sys/class/net/${WIFI_IFACE}/statistics/tx_bytes" 2>/dev/null
        echo $((_rx + _tx))
}

# Returns 0 if wifi is currently enabled at the framework level, 1 if disabled.
is_wifi_enabled() {
        _st=$(dumpsys wifi 2>/dev/null | grep 'Wi-Fi is' | head -1)
        case "$_st" in
                *enabled*) return 0 ;;
                *)         return 1 ;;
        esac
}

# The wifi power-gating daemon. Runs as long as the module is active. The state machine has two
# positions:
#
#   WIFI_ON   — the radio is enabled. The daemon polls screen state and, when the screen goes off
#               with the PCM open, transitions to the quiet-period measurement. If the screen comes
#               back on or the PCM closes before the quiet period expires, it stays here.
#
#   WIFI_OFF  — the radio is disabled. The daemon polls screen state and PCM state. On screen-on or
#               PCM-close, it re-enables the radio immediately and returns to WIFI_ON.
#
# The quiet-period measurement is not a separate state; it is a timed loop within WIFI_ON that
# samples traffic and either transitions to WIFI_OFF or aborts back to the polling loop.
#
# The daemon does not interfere with a user manually toggling wifi. If wifi is found disabled on
# entry to a screen-on event when the daemon did not disable it, no action is taken.
do_wifigated() {
        detect_files
        _gated=0                             # 1 if this daemon disabled wifi and has not re-enabled it
        log "wifigated: monitoring ${WIFI_IFACE}; quiet=${WIFI_QUIET_SECS}s idle=${WIFI_IDLE_BYTES}B"

        while :; do
                # ---- WIFI_OFF state: wait for a reason to re-enable ----
                if [ "$_gated" = 1 ]; then
                        if is_screen_on; then
                                svc wifi enable
                                _gated=0
                                log "wifigated: screen on -> wifi enabled"
                        else
                                read_hw
                                if [ "$HW_STATE" != open ]; then
                                        svc wifi enable
                                        _gated=0
                                        log "wifigated: pcm closed -> wifi enabled"
                                fi
                        fi
                        sleep "$WIFI_SCREEN_POLL"
                        continue
                fi

                # ---- WIFI_ON state: check whether conditions for gating are met ----
                if is_screen_on; then
                        sleep "$WIFI_SCREEN_POLL"
                        continue
                fi

                read_hw
                if [ "$HW_STATE" != open ]; then
                        # Screen off, not playing. Wait for screen-on, then the user will interact
                        # and wifi should be available. Gate after a shorter idle once the screen
                        # goes off again.
                        sleep "$WIFI_SCREEN_POLL"
                        continue
                fi

                # Screen is off, PCM is open. Enter the quiet-period measurement.
                # Sample traffic over WIFI_QUIET_SECS. If traffic stays below WIFI_IDLE_BYTES per
                # sample for the full window, disable wifi.
                _prev=$(wifi_traffic_bytes) || { sleep "$WIFI_POLL"; continue; }
                _quiet_elapsed=0
                _aborted=0

                while [ "$_quiet_elapsed" -lt "$WIFI_QUIET_SECS" ]; do
                        sleep "$WIFI_POLL"
                        _quiet_elapsed=$((_quiet_elapsed + WIFI_POLL))

                        # Abort if screen turned on.
                        if is_screen_on; then
                                _aborted=1; break
                        fi

                        # Abort if PCM closed.
                        read_hw
                        if [ "$HW_STATE" != open ]; then
                                _aborted=1; break
                        fi

                        # Measure traffic delta.
                        _cur=$(wifi_traffic_bytes) || { _aborted=1; break; }
                        _delta=$((_cur - _prev))
                        # Absolute value (in case counters wrap, though unlikely within one sample).
                        [ "$_delta" -lt 0 ] && _delta=$((-_delta))
                        _prev=$_cur

                        if [ "$_delta" -gt "$WIFI_IDLE_BYTES" ]; then
                                # Traffic above threshold. Reset the quiet window and re-enter the
                                # outer loop, which will start a fresh measurement if conditions
                                # still hold.
                                _aborted=1; break
                        fi
                done

                if [ "$_aborted" = 1 ]; then
                        sleep "$WIFI_SCREEN_POLL"
                        continue
                fi

                # Full quiet period elapsed with no significant traffic. Disable wifi.
                svc wifi disable
                _gated=1
                log "wifigated: screen off, pcm open, traffic idle ${WIFI_QUIET_SECS}s -> wifi disabled"
        done
}

# ---------------------------------------------------------------------------------------------------
# Subcommand: boot (run once from service.sh, after service.bootanim.exit == 1)
# ---------------------------------------------------------------------------------------------------

do_boot() {
        mkdir -p "$STATE_DIR" 2>/dev/null
        rotate_log
        # The cpuset snapshot is written once and then preserved, NOT refreshed per run.
        #
        # It was truncated here on the assumption that do_boot runs once per boot, where a fresh snapshot
        # is the correct thing. It is not correct for a second run on an already-configured system, which
        # is how a configuration change is applied without rebooting: retarget_tree records each set's
        # current cpus before overwriting it, so a re-run would record the values the FIRST run wrote —
        # $BIG — as though they were stock, and do_revert would then "restore" every stock cpuset to the
        # big cluster and leave the device permanently partitioned with no route back short of a reboot.
        #
        # Only the first run observes the true stock masks, so only the first run may write the snapshot.
        # do_revert replays the first recorded value per path, which makes the file correct however many
        # times do_boot has appended to it.
        if [ -s "$BAK" ]; then
                log "snapshot: keeping existing stock cpuset snapshot ($BAK)"
        else
                : > "$BAK"
        fi
        ensure_self_exec
        detect_files
        verify_topology
        if [ "$DISABLE_SWEEP" = 1 ]; then
                stop_services
                disable_apps
                hard_disable_apps
                stop_apps
        fi
        ensure_set "$BIGSINK"   "$BIG"    || exit 1
        ensure_set "$AUDIO_SET" "$AUDIO_CPUS" || exit 1
        retarget_tree "$CPUSET"
        drain_root
        # After drain_root, so the cpuset partition has already taken everything it can reach and what
        # remains on the littles is kernel-side. Before cpu_gpu_baseline only for readability; the two
        # are independent.
        pin_irqs
        # After pin_irqs, so a threaded handler is affined to the target its interrupt was just given
        # rather than to the one it held before the sort.
        pin_irq_threads
        confine_workqueues
        # After confine_workqueues, so the global unbound cpumask is already in place and this pass only
        # has to catch the workers that predate it rather than racing pools into existence.
        pin_kthreads
        sink_init
        cpu_gpu_baseline
        launch_daemons
        log "boot prep complete"
}

# ---------------------------------------------------------------------------------------------------
# Subcommand: revert (live rollback)
# ---------------------------------------------------------------------------------------------------

do_revert() {
        detect_files
        enable_apps
        stop_daemons
        # Re-enable wifi if the gating daemon had disabled it. stop_daemons kills the daemon but
        # does not know whether it had acted, so this is unconditional — enabling an already-enabled
        # radio is a no-op.
        is_wifi_enabled || { svc wifi enable; log "revert: re-enabled wifi"; }
        # IRQ affinity is not restored (see the note above pin_irqs); the unbound workqueue cpumask is,
        # because it is a single global setting with a recorded prior value and no such caveat.
        restore_workqueues
        for base in /sys/kernel/tracing /sys/kernel/debug/tracing; do
                ti="$base/instances/dx180"
                [ -d "$ti" ] || continue
                echo 0 > "$ti/events/sched/sched_process_fork/enable" 2>/dev/null
                rmdir "$ti" 2>/dev/null && log "removed trace instance"
        done
        if [ -s "$BAK" ]; then
                # First recorded value per path wins. do_boot appends on every run and only the first run
                # observed the true stock masks, so a later duplicate holds what this module itself wrote
                # and must not be replayed. Tracking seen paths in a string rather than replaying blindly
                # keeps the restore correct however many times do_boot has run since the reboot.
                seen=""
                while read -r p m; do
                        [ -n "$p" ] || continue
                        case " $seen " in *" $p "*) continue ;; esac
                        seen="$seen $p"
                        [ -f "$p/$CF" ] && echo "$m" > "$p/$CF" 2>/dev/null
                done < "$BAK"
                rm -f "$BAK"
                log "restored stock cpus from snapshot"
        else
                log "no snapshot; reboot restores stock masks"
        fi
        for s in "$AUDIO_SET" "$BIGSINK"; do
                [ -d "$s" ] || continue
                if [ -f "$s/$TF" ]; then
                        while read -r tid; do echo "$tid" > "$CPUSET/$TF" 2>/dev/null; done < "$s/$TF"
                fi
                rmdir "$s" 2>/dev/null && log "removed ${s##*/}"
        done
        log "revert complete (reboot also restores all runtime sysfs)"
}

usage() { echo "usage: ${0##*/} {boot|pcm|forkwatch|maintslow|pinwatch|wifigated|irqsort|irqcheck|irqstat|irqrate|wqconfine|kthreadsort|revert}"; }

# ---------------------------------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------------------------------

case "$1" in
        boot)      do_boot ;;
        pcm)       do_pcm ;;
        forkwatch) do_forkwatch ;;
        maintslow) maintain_slow ;;
        pinwatch)  do_pinwatch ;;
        wifigated) do_wifigated ;;
        irqsort)   pin_irqs; pin_irq_threads ;;
        wqconfine) confine_workqueues ;;
        kthreadsort) pin_kthreads ;;
        irqcheck)  pin_irqs check
                   echo "drift: ${DRIFT_N} interrupt(s) off target${DRIFT_NAMES:+ — }${DRIFT_NAMES}" ;;
        irqstat)   irq_report ;;
        # $2, not $1: this dispatch does not shift, so $1 is still the subcommand name.
        irqrate)   irq_rate "${2:-30}" ;;
        revert)    do_revert ;;
        *)
                # inotifyd invokes as: <events> <watched-path> <filename>, so an inotify event is
                # recognised by $2 holding an ABSOLUTE PATH — not merely by $2 being non-empty, which is
                # what this tested before.
                #
                # Any subcommand this build does not implement, given an argument, matched that test and
                # ran the PCM handler instead of reporting the mistake. `irqrate 60` against a build
                # predating irqrate is the case that surfaced it: no output, no error, and do_pcm ends in
                # stop_apps, so every attempt force-stopped seven packages and set a frequency tier from a
                # stream state nobody had asked about. Visible in the 2026-09-26 log as
                # `force-stopped com.android.settings` at 14:52:47, 15:28:48, 15:30:01 with no PCM event
                # anywhere near them, and it is the most likely explanation for the device running warm
                # during that session.
                #
                # A wrong subcommand now exits non-zero with the usage text, which is what a caller — human
                # or script — needs in order to notice that the installed build is not the one expected.
                if [ -z "$1" ]; then
                        usage; exit 2
                fi
                case "$2" in
                        /*) do_pcm ;;
                        *)  echo "${0##*/}: unknown subcommand '$1'" >&2; usage; exit 2 ;;
                esac ;;
esac
