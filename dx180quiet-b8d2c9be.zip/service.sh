#!/system/bin/sh
#
# Magisk late_start service entry point for dx180quiet.
#
# Restores the execute bit on the module's scripts before launching anything, because config.sh's
# set_perm_recursive applies a 0644 file mode at install time and clears it.
#
# The failure that produces is silent and asymmetric, which is what makes the chmod worth doing here
# rather than relying on it having been done by hand. Magisk invokes this script through an
# interpreter, so it runs regardless of its own mode; it launches dx180quiet.sh the same way, so boot
# completes and writes a full, healthy-looking sweep to the log. But inotifyd must exec the program it
# is handed, so without the bit every PCM event is dropped with no error recorded anywhere, and the
# backgrounded daemons fail the same way. Observed on the 2026-09-24 10:10:17 boot: a complete boot
# block, then 45 minutes of playback with no further log output and an empty /dev/cpuset/audio.
#
# dx180quiet.sh carries its own ensure_self_exec guard as a backstop. This is the earlier and more
# reliable of the two, since it runs before inotifyd is ever started.

MODDIR=${0%/*}
LOG="$MODDIR/quiet.log"

chmod 0755 "$MODDIR"/*.sh 2>/dev/null

while [ "$(getprop service.bootanim.exit)" != 1 ]; do sleep 10; done
nohup /system/bin/sh "$MODDIR/dx180quiet.sh" boot >> "$LOG" 2>&1 &
