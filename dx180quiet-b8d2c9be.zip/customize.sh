#!/system/bin/sh
#
# Magisk installer hook for dx180quiet (Magisk v20.4+ / KernelSU / APatch).
#
# The legacy template's config.sh is retained in this module for reference, but is not read by the
# current module_installer.sh, which sources customize.sh instead. The permission fix below therefore
# has to exist here as well as there; the two are equivalent and both are required for the module to
# install correctly under either installer generation.
#
# install_module applies `set_perm_recursive $MODPATH 0 0 0755 0644` before this hook runs. That
# blanket 0644 clears the execute bit on every script in the module, and the resulting failure is
# silent and asymmetric: service.sh and dx180quiet.sh are both invoked through an interpreter and run
# anyway, so boot completes and writes a full, healthy-looking sweep to the log, while inotifyd — which
# must exec the program it is handed — drops every PCM event with no error recorded anywhere. Observed
# on the 2026-09-24 10:10:17 boot as a complete boot block followed by 45 minutes of playback with no
# further log output and an empty /dev/cpuset/audio. See the 2026-09-24 (second) entry in
# dx180quiet.receipt.md.

ui_print "- dx180quiet"
ui_print "  target: iBasso DX180"

ui_print "- Setting permissions"

# Every shell script in the module, not an enumerated list: an enumeration silently omits any script
# added later, and the omission does not surface until a PCM event is dropped at runtime.
set_perm_recursive "$MODPATH" 0 0 0755 0644
for f in "$MODPATH"/*.sh; do
    [ -f "$f" ] || continue
    set_perm "$f" 0 0 0755
done

ui_print "- Verifying"

# The execute bit is verified rather than assumed, because the failure it produces is invisible at
# boot. An installation that cannot set it is reported here rather than at the next PCM event.
missing=""
for f in "$MODPATH"/dx180quiet.sh "$MODPATH"/service.sh; do
    [ -x "$f" ] || missing="$missing ${f##*/}"
done
if [ -n "$missing" ]; then
    ui_print "  ! not executable:$missing"
    ui_print "  ! inotifyd will drop PCM events; check the installer environment"
else
    ui_print "  ok: dx180quiet.sh, service.sh executable"
fi

ui_print "- Installed. Reboot to apply."
ui_print "  log: /data/local/tmp/dx180quiet.log"
ui_print "  revert without uninstalling: sh \$MODDIR/dx180quiet.sh revert"
